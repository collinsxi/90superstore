import { Instagram, Youtube, Music, Facebook, ArrowRight } from "lucide-react"

export default function SocialMediaSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
      <div className="container-full">
        <div className="max-w-4xl mx-auto text-center space-y-12">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold">Connect With 90SUPERSTORE Everywhere</h2>
            <p className="text-lg opacity-90">
              Follow us for exclusive deals, behind-the-scenes content, and daily shopping tips
            </p>
          </div>

          {/* Social Links */}
          <div className="grid md:grid-cols-4 gap-4">
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 hover:bg-white/20 rounded-lg p-6 transition group"
            >
              <Music className="mx-auto mb-3 group-hover:scale-110 transition" size={32} />
              <p className="font-bold">TikTok</p>
              <p className="text-sm opacity-75 mt-1">Trending & Reviews</p>
            </a>

            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 hover:bg-white/20 rounded-lg p-6 transition group"
            >
              <Instagram className="mx-auto mb-3 group-hover:scale-110 transition" size={32} />
              <p className="font-bold">Instagram</p>
              <p className="text-sm opacity-75 mt-1">Product Photos</p>
            </a>

            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 hover:bg-white/20 rounded-lg p-6 transition group"
            >
              <Youtube className="mx-auto mb-3 group-hover:scale-110 transition" size={32} />
              <p className="font-bold">YouTube</p>
              <p className="text-sm opacity-75 mt-1">Unboxings & Reviews</p>
            </a>

            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 hover:bg-white/20 rounded-lg p-6 transition group"
            >
              <Facebook className="mx-auto mb-3 group-hover:scale-110 transition" size={32} />
              <p className="font-bold">Facebook</p>
              <p className="text-sm opacity-75 mt-1">Community & Updates</p>
            </a>
          </div>

          {/* CTA Buttons */}
          <div className="flex gap-4 justify-center flex-wrap">
            <button className="bg-white text-primary font-bold px-8 py-3 rounded-lg hover:opacity-90 transition flex items-center gap-2">
              Follow Us <ArrowRight size={18} />
            </button>
            <button className="border-2 border-white text-white font-bold px-8 py-3 rounded-lg hover:bg-white hover:text-primary transition">
              Subscribe for Updates
            </button>
          </div>

          {/* Engagement Stats */}
          <div className="grid md:grid-cols-3 gap-6 pt-8 border-t border-white/20">
            <div>
              <p className="text-3xl font-bold">50K+</p>
              <p className="text-sm opacity-75">Happy Followers</p>
            </div>
            <div>
              <p className="text-3xl font-bold">1000+</p>
              <p className="text-sm opacity-75">Satisfied Customers</p>
            </div>
            <div>
              <p className="text-3xl font-bold">4.8★</p>
              <p className="text-sm opacity-75">Average Rating</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
