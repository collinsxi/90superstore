import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="relative bg-gradient-to-r from-primary to-blue-600 text-white py-20 overflow-hidden">
      <img
        src="/online-shopping-marketplace-nigeria-china-usa-prod.jpg"
        alt="Shopping products"
        className="absolute inset-0 w-full h-full object-cover opacity-30"
      />

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
      </div>

      <div className="container-full relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance">Welcome to 90SUPERSTORE</h1>
            <p className="text-lg md:text-xl text-blue-100">
              Your global store for products, original artwork, and digital services.
            </p>
            <div className="flex gap-4">
              <Link
                href="/marketplace"
                className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-lg font-bold hover:bg-blue-50 transition"
              >
                Explore Marketplace
                <ArrowRight size={20} />
              </Link>
              <Link
                href="/amazing-art"
                className="inline-flex items-center gap-2 border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white hover:text-primary transition"
              >
                View Artwork
                <ArrowRight size={20} />
              </Link>
            </div>
          </div>

          {/* Right Image */}
          <div className="hidden md:block">
            <div className="relative h-96 bg-blue-700 rounded-2xl overflow-hidden shadow-2xl">
              <img src="/premium-electronics-gadgets-shopping-display.jpg" alt="Premium products" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>

        {/* Trust Stats */}
        <div className="grid grid-cols-3 gap-4 mt-16">
          <div className="text-center">
            <p className="text-3xl font-bold">10K+</p>
            <p className="text-blue-100">Products</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold">50K+</p>
            <p className="text-blue-100">Happy Customers</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold">24/7</p>
            <p className="text-blue-100">Support</p>
          </div>
        </div>
      </div>
    </section>
  )
}
