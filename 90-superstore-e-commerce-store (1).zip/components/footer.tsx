import Link from "next/link"
import { Facebook, Twitter, Instagram, Youtube } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-secondary text-white py-16">
      <div className="container-full">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold">
              90<span className="text-primary">SUPER</span>
              <span className="text-blue-400">STORE</span>
            </h3>
            <p className="text-gray-300">Your trusted online marketplace for quality products at the best prices.</p>
            <div className="space-y-2 text-sm text-gray-300">
              <p>
                <a href="mailto:90Superstore@gmail.com" className="hover:text-primary transition">
                  📧 90Superstore@gmail.com
                </a>
              </p>
              <p>
                <a
                  href="https://wa.me/2348135642177"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary transition"
                >
                  💬 08135642177
                </a>
              </p>
            </div>
            <div className="flex gap-4">
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
                title="TikTok"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.68v13.67a2.89 2.89 0 1 1-5.92-2.32c.44-.16.88-.23 1.39-.23A2.88 2.88 0 0 1 9.83 13.1V9.04a6.26 6.26 0 0 0-5.40 6.05 6.26 6.26 0 0 0 5.40 6.05v-3.73a8.52 8.52 0 0 0 3.14-.6v3.73a9 9 0 1 1 3.14-11.50" />
                </svg>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
              >
                <Facebook size={20} />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
              >
                <Youtube size={20} />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/shop" className="hover:text-primary transition">
                  Shop All
                </Link>
              </li>
              <li>
                <Link href="/digital-store" className="hover:text-primary transition">
                  Digital Store
                </Link>
              </li>
              <li>
                <Link href="/hot-deals" className="hover:text-primary transition">
                  Hot Deals
                </Link>
              </li>
              <li>
                <Link href="/track-order" className="hover:text-primary transition">
                  Track Order
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Customer Service</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/contact" className="hover:text-primary transition">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-primary transition">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-primary transition">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="hover:text-primary transition">
                  Shipping Info
                </Link>
              </li>
            </ul>
          </div>

          {/* Policies */}
          <div className="space-y-4">
            <h4 className="font-bold text-lg">Legal & Policies</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/privacy" className="hover:text-primary transition">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-primary transition">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/shipping-policy" className="hover:text-primary transition">
                  Shipping Policy
                </Link>
              </li>
              <li>
                <Link href="/refund" className="hover:text-primary transition">
                  Refund Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-700 pt-8">
          {/* Payment Methods */}
          <div className="mb-6">
            <p className="text-sm text-gray-400 mb-2">We Accept</p>
            <div className="flex gap-3 flex-wrap">
              <div className="bg-white text-black px-3 py-1 rounded text-xs font-bold">Visa</div>
              <div className="bg-white text-black px-3 py-1 rounded text-xs font-bold">MasterCard</div>
              <div className="bg-primary text-white px-3 py-1 rounded text-xs font-bold">Paystack</div>
              <div className="bg-orange-500 text-white px-3 py-1 rounded text-xs font-bold">Flutterwave</div>
              <div className="bg-blue-600 text-white px-3 py-1 rounded text-xs font-bold">PayPal</div>
              <div className="bg-black text-white px-3 py-1 rounded text-xs font-bold">Apple Pay</div>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center text-gray-400 text-sm">
            <p>© {currentYear} 90SUPERSTORE. All rights reserved. | Bringing quality products to your doorstep</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
