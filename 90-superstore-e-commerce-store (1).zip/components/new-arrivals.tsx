"use client"

import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"

const newArrivals = [
  {
    id: 5,
    name: "Portable Power Bank 50000mAh",
    price: "₦9,999",
    originalPrice: "₦14,999",
    rating: 4.7,
    reviews: 89,
    image: "/portable-power-bank.png",
    badge: "NEW",
  },
  {
    id: 6,
    name: "Bluetooth Speaker Pro",
    price: "₦7,999",
    originalPrice: "₦11,999",
    rating: 4.8,
    reviews: 156,
    image: "/bluetooth-speaker.jpg",
    badge: "NEW",
  },
  {
    id: 7,
    name: "Phone Screen Protector",
    price: "₦1,499",
    originalPrice: "₦2,499",
    rating: 4.5,
    reviews: 234,
    image: "/screen-protector.png",
    badge: "NEW",
  },
  {
    id: 8,
    name: "Wireless Charging Pad",
    price: "₦5,999",
    originalPrice: "₦8,999",
    rating: 4.6,
    reviews: 112,
    image: "/wireless-charger.png",
    badge: "NEW",
  },
]

export default function NewArrivals() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container-full">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">New Arrivals</h2>
          <p className="text-muted-foreground text-lg">Fresh products just added to our store</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {newArrivals.map((product) => (
            <Link key={product.id} href={`/product/${product.id}`} className="card-product group overflow-hidden">
              <div className="relative overflow-hidden bg-gray-100 h-48">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                {product.badge && (
                  <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    {product.badge}
                  </div>
                )}
              </div>

              <div className="p-4 space-y-3">
                <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition">
                  {product.name}
                </h3>

                <div className="flex items-center gap-1">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className={i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">({product.reviews})</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-primary">{product.price}</span>
                  <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                </div>

                <button
                  onClick={(e) => {
                    e.preventDefault()
                  }}
                  className="w-full bg-primary text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={18} />
                  Add to Cart
                </button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
