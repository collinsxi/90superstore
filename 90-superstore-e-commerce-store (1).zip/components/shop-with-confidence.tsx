import { Shield, Zap, RotateCcw, Star, Lock, TrendingUp } from "lucide-react"

export default function ShopWithConfidence() {
  const badges = [
    {
      icon: Lock,
      title: "100% Secure Checkout",
      description: "SSL encrypted, safe payments",
    },
    {
      icon: Zap,
      title: "Fast Delivery",
      description: "1-5 days nationwide",
    },
    {
      icon: RotateCcw,
      title: "7-Day Returns",
      description: "Easy, no-hassle returns",
    },
    {
      icon: Star,
      title: "Trusted Store",
      description: "1000+ happy customers",
    },
    {
      icon: TrendingUp,
      title: "Best Price Guarantee",
      description: "We match or beat prices",
    },
    {
      icon: Shield,
      title: "Money-Back Guarantee",
      description: "Not satisfied? Full refund",
    },
  ]

  return (
    <section className="py-16">
      <div className="container-full">
        <h2 className="text-3xl font-bold text-center mb-12">Shop With Confidence</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {badges.map((badge, i) => {
            const IconComponent = badge.icon
            return (
              <div
                key={i}
                className="border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition"
              >
                <IconComponent className="text-primary mx-auto mb-3" size={32} />
                <h3 className="font-bold mb-1">{badge.title}</h3>
                <p className="text-sm text-muted-foreground">{badge.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
