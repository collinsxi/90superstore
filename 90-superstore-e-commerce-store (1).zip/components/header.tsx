"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, ShoppingCart, Menu, X, MessageCircle } from "lucide-react"
import Logo from "./logo"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <>
      <div className="bg-primary text-white py-2 text-sm">
        <div className="container-full flex justify-between items-center">
          <div className="flex gap-6">
            <a href="mailto:90Superstore@gmail.com" className="hover:text-blue-100 transition">
              Email: 90Superstore@gmail.com
            </a>
            <a
              href="https://wa.me/2348135642177"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-blue-100 transition"
            >
              WhatsApp: 08135642177
            </a>
          </div>
        </div>
      </div>

      <header className="sticky top-12 z-50 bg-white border-b border-gray-200">
        <div className="container-full">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <Logo />

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/" className="text-foreground font-medium hover:text-primary transition">
                Home
              </Link>
              <Link href="/amazing-art" className="text-foreground font-medium hover:text-primary transition">
                Amazing Art
              </Link>
              <Link href="/marketplace" className="text-foreground font-medium hover:text-primary transition">
                Marketplace
              </Link>
              <Link href="/digital-services" className="text-foreground font-medium hover:text-primary transition">
                Digital Services
              </Link>
              <Link href="/about" className="text-foreground font-medium hover:text-primary transition">
                About
              </Link>
              <Link href="/contact" className="text-foreground font-medium hover:text-primary transition">
                Contact
              </Link>
            </nav>

            {/* Right Icons */}
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center bg-gray-100 rounded-lg px-3 py-2">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="bg-transparent outline-none flex-1 text-sm"
                />
                <Search size={18} className="text-muted-foreground" />
              </div>
              <Link href="/cart" className="relative">
                <ShoppingCart size={24} className="text-foreground hover:text-primary transition" />
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
              </Link>
              <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <nav className="md:hidden pb-4 border-t border-gray-200">
              <Link href="/" className="block px-0 py-2 text-foreground hover:text-primary">
                Home
              </Link>
              <Link href="/amazing-art" className="block px-0 py-2 text-foreground hover:text-primary">
                Amazing Art
              </Link>
              <Link href="/marketplace" className="block px-0 py-2 text-foreground hover:text-primary">
                Marketplace
              </Link>
              <Link href="/digital-services" className="block px-0 py-2 text-foreground hover:text-primary">
                Digital Services
              </Link>
              <Link href="/about" className="block px-0 py-2 text-foreground hover:text-primary">
                About
              </Link>
              <Link href="/contact" className="block px-0 py-2 text-foreground hover:text-primary">
                Contact
              </Link>
            </nav>
          )}
        </div>
      </header>

      <a
        href="https://wa.me/2348135642177"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition z-40"
        title="Chat on WhatsApp"
      >
        <MessageCircle size={24} />
      </a>
    </>
  )
}
