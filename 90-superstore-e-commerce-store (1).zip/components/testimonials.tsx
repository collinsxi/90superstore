"use client"

import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { useState } from "react"

const testimonials = [
  {
    id: 1,
    name: "Chioma Okafor",
    role: "Verified Buyer",
    content:
      "Amazing quality and super fast delivery! The products exceeded my expectations. Highly recommend 90SUPERSTORE!",
    rating: 5,
    avatar: "/diverse-woman-portrait.png",
  },
  {
    id: 2,
    name: "Tunde Adeyemi",
    role: "Verified Buyer",
    content:
      "Best prices I've seen for electronics. Customer service is responsive and helpful. Will definitely order again!",
    rating: 5,
    avatar: "/man.jpg",
  },
  {
    id: 3,
    name: "Amara Nwosu",
    role: "Verified Buyer",
    content: "Excellent range of products. The payment process is smooth and secure. I feel confident shopping here!",
    rating: 4.5,
    avatar: "/diverse-woman-smiling.png",
  },
  {
    id: 4,
    name: "Oluwaseun Balogun",
    role: "Verified Buyer",
    content: "Great deals and authentic products. 90SUPERSTORE is my go-to store for all my tech needs.",
    rating: 5,
    avatar: "/smiling-man.png",
  },
]

export default function Testimonials() {
  const [current, setCurrent] = useState(0)

  const next = () => {
    setCurrent((prev) => (prev + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="container-full">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <p className="text-muted-foreground text-lg">Real reviews from real customers</p>
        </div>

        {/* Testimonial Slider */}
        <div className="relative bg-white rounded-2xl p-8 md:p-12 shadow-lg">
          <div className="grid md:grid-cols-3 gap-8 items-center">
            {/* Previous Button */}
            <button
              onClick={prev}
              className="hidden md:flex absolute -left-6 top-1/2 -translate-y-1/2 bg-primary text-white p-3 rounded-full hover:bg-blue-700 transition"
            >
              <ChevronLeft size={24} />
            </button>

            {/* Main Testimonial */}
            <div className="md:col-span-2 space-y-4">
              {/* Rating */}
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    className={
                      i < Math.floor(testimonials[current].rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-lg text-foreground italic">"{testimonials[current].content}"</p>

              {/* Author */}
              <div className="flex items-center gap-4 pt-4">
                <img
                  src={testimonials[current].avatar || "/placeholder.svg"}
                  alt={testimonials[current].name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="font-semibold text-foreground">{testimonials[current].name}</p>
                  <p className="text-sm text-muted-foreground">{testimonials[current].role}</p>
                </div>
              </div>
            </div>

            {/* Next Button */}
            <button
              onClick={next}
              className="hidden md:flex absolute -right-6 top-1/2 -translate-y-1/2 bg-primary text-white p-3 rounded-full hover:bg-blue-700 transition"
            >
              <ChevronRight size={24} />
            </button>
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden flex gap-2 justify-center mt-6">
            <button
              onClick={prev}
              className="flex items-center justify-center bg-primary text-white p-2 rounded-full hover:bg-blue-700 transition"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={next}
              className="flex items-center justify-center bg-primary text-white p-2 rounded-full hover:bg-blue-700 transition"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrent(index)}
                className={`h-2 rounded-full transition ${index === current ? "bg-primary w-8" : "bg-gray-300 w-2"}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
