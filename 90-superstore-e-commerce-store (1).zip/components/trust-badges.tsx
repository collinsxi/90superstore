import { Shield, Truck, RefreshCw } from "lucide-react"

const badges = [
  {
    icon: Shield,
    title: "Secure Checkout",
    description: "SSL encrypted transactions",
  },
  {
    icon: Truck,
    title: "Fast Delivery",
    description: "Nationwide delivery within 48 hours",
  },
  {
    icon: RefreshCw,
    title: "Money-Back Guarantee",
    description: "30-day hassle-free returns",
  },
]

export default function TrustBadges() {
  return (
    <section className="py-16 bg-white">
      <div className="container-full">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {badges.map((badge, index) => {
            const Icon = badge.icon
            return (
              <div key={index} className="text-center space-y-4">
                <div className="inline-flex bg-blue-100 text-primary p-4 rounded-full">
                  <Icon size={32} />
                </div>
                <h3 className="text-xl font-bold text-foreground">{badge.title}</h3>
                <p className="text-muted-foreground">{badge.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
