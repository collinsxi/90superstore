"use client"

import Link from "next/link"
import { Flame } from "lucide-react"

const trendingProducts = [
  {
    id: 9,
    name: "Gaming Mouse RGB",
    price: "₦6,999",
    image: "/gaming-mouse.png",
    sales: 1200,
  },
  {
    id: 10,
    name: "Mechanical Keyboard",
    price: "₦12,999",
    image: "/mechanical-keyboard.png",
    sales: 980,
  },
  {
    id: 11,
    name: "USB Hub 7-in-1",
    price: "₦4,999",
    image: "/usb-hub.png",
    sales: 856,
  },
  {
    id: 12,
    name: "Phone Ring Stand",
    price: "₦2,999",
    image: "/phone-ring.jpg",
    sales: 1456,
  },
]

export default function TrendingNow() {
  return (
    <section className="py-16 bg-white">
      <div className="container-full">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Flame size={24} className="text-red-500" />
              <h2 className="text-3xl md:text-4xl font-bold">Trending Now</h2>
            </div>
            <p className="text-muted-foreground">Most purchased products this week</p>
          </div>
          <Link href="/shop" className="btn-secondary hidden md:inline-block">
            View All
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingProducts.map((product, index) => (
            <Link
              key={product.id}
              href={`/product/${product.id}`}
              className="card-product p-4 relative overflow-hidden group"
            >
              {/* Ranking Badge */}
              <div className="absolute -top-1 -left-1 bg-red-500 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">
                #{index + 1}
              </div>

              <div className="bg-gray-100 h-40 rounded-lg overflow-hidden mb-4">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                />
              </div>

              <h3 className="font-semibold text-foreground mb-1 line-clamp-2">{product.name}</h3>
              <p className="text-sm text-muted-foreground mb-3">{product.sales.toLocaleString()} sold</p>
              <p className="text-lg font-bold text-primary">{product.price}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
