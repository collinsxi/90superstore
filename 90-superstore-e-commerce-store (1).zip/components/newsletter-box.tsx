"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Send } from "lucide-react"

export default function NewsletterBox() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => {
      setEmail("")
      setSubmitted(false)
    }, 3000)
  }

  return (
    <section className="py-16 bg-gradient-to-r from-primary to-blue-600 text-white">
      <div className="container-full">
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <div className="flex justify-center mb-4">
            <Mail size={40} />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold">Subscribe to Our Newsletter</h2>
          <p className="text-lg text-blue-100">
            Get exclusive deals, new arrivals, and special offers delivered to your inbox
          </p>

          <form onSubmit={handleSubmit} className="flex gap-2 mt-6">
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 px-4 py-3 rounded-lg text-foreground outline-none"
            />
            <button
              type="submit"
              className="bg-secondary text-white px-8 py-3 rounded-lg font-bold hover:bg-black transition flex items-center gap-2"
            >
              <Send size={18} />
              <span className="hidden sm:inline">Subscribe</span>
            </button>
          </form>

          {submitted && <p className="text-green-200 text-sm">Thank you! Check your email for exclusive offers.</p>}
        </div>
      </div>
    </section>
  )
}
