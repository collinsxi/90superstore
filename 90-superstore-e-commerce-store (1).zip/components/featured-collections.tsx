import Link from "next/link"

const categories = [
  {
    name: "Phones & Gadgets",
    image: "/smartphone-mobile-phone-gadgets.jpg",
    link: "/category/phones-gadgets",
  },
  {
    name: "Smart Accessories",
    image: "/power-bank-earbuds-wireless-charger.jpg",
    link: "/category/accessories",
  },
  {
    name: "Home & Kitchen",
    image: "/kitchen-cookware-appliances-blender-pots.jpg",
    link: "/category/home-kitchen",
  },
  {
    name: "Health & Beauty",
    image: "/cosmetics-skincare-beauty-products.jpg",
    link: "/category/health-beauty",
  },
  {
    name: "Fashion",
    image: "/clothing-fashion-men-women-dress-shirt.jpg",
    link: "/category/fashion",
  },
  {
    name: "Electronics",
    image: "/speakers-headphones-audio-equipment.jpg",
    link: "/category/electronics",
  },
]

const additionalCategories = [
  {
    name: "Local Hot Deals",
    image: "/nigerian-products-local-marketplace.jpg",
    link: "/category/local-deals",
  },
  {
    name: "Kids & Baby",
    image: "/toys-baby-items-children-products.jpg",
    link: "/category/kids-baby",
  },
  {
    name: "Fitness & Wellness",
    image: "/gym-fitness-equipment-dumbbells-yoga.jpg",
    link: "/category/fitness",
  },
  {
    name: "Car Accessories",
    image: "/car-accessories-dashboard-led-light.jpg",
    link: "/category/car-accessories",
  },
  {
    name: "Smart Watches",
    image: "/smartwatch-wearable-tech-display.jpg",
    link: "/category/smart-watches",
  },
  {
    name: "Dropshipping Specials",
    image: "/chinese-marketplace-products-wholesale.jpg",
    link: "/category/dropshipping",
  },
]

export default function FeaturedCollections() {
  return (
    <section className="py-16 bg-background">
      <div className="container-full">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Collections</h2>
          <p className="text-muted-foreground text-lg">
            Browse our extensive range of premium products across all categories
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link
              key={category.name}
              href={category.link}
              className="relative card-product overflow-hidden h-64 rounded-xl hover:shadow-lg transition"
            >
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.name}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 hover:bg-black/30 transition" />
              <div className="relative z-10 flex flex-col justify-center items-center h-full text-center text-white">
                <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                <p className="text-sm text-blue-100">Explore collection</p>
              </div>
            </Link>
          ))}
        </div>

        {/* Additional Categories */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {additionalCategories.map((category) => (
            <Link
              key={category.name}
              href={category.link}
              className="relative card-product overflow-hidden h-64 rounded-xl hover:shadow-lg transition"
            >
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.name}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 hover:bg-black/30 transition" />
              <div className="relative z-10 flex flex-col justify-center items-center h-full text-center text-white">
                <h3 className="text-xl font-bold">{category.name}</h3>
                <p className="text-sm text-blue-100">Explore collection</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
