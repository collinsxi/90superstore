"use client"

import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"

const bestSellers = [
  {
    id: 1,
    name: "Premium Wireless Earbuds",
    price: "₦8,999",
    originalPrice: "₦12,999",
    rating: 4.8,
    reviews: 234,
    image: "/wireless-earbuds.png",
    badge: "25% OFF",
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    price: "₦15,999",
    originalPrice: "₦19,999",
    rating: 4.7,
    reviews: 189,
    image: "/smartwatch-lifestyle.png",
    badge: "20% OFF",
  },
  {
    id: 3,
    name: "USB-C Fast Charger",
    price: "₦3,499",
    originalPrice: "₦4,999",
    rating: 4.9,
    reviews: 512,
    image: "/usb-charger.jpg",
    badge: "30% OFF",
  },
  {
    id: 4,
    name: "Phone Stand Mount",
    price: "₦1,999",
    originalPrice: "₦2,999",
    rating: 4.6,
    reviews: 145,
    image: "/phone-stand.jpg",
    badge: "33% OFF",
  },
]

export default function BestSellers() {
  return (
    <section className="py-16 bg-white">
      <div className="container-full">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Best Sellers</h2>
          <p className="text-muted-foreground text-lg">Most loved products by our customers</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((product) => (
            <Link key={product.id} href={`/product/${product.id}`} className="card-product group overflow-hidden">
              {/* Product Image */}
              <div className="relative overflow-hidden bg-gray-100 h-48">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                {product.badge && <div className="badge-discount">{product.badge}</div>}
              </div>

              {/* Product Info */}
              <div className="p-4 space-y-3">
                <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition">
                  {product.name}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-1">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className={i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">({product.reviews})</span>
                </div>

                {/* Price */}
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-primary">{product.price}</span>
                  <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                </div>

                {/* Add to Cart Button */}
                <button
                  onClick={(e) => {
                    e.preventDefault()
                    // Add to cart logic
                  }}
                  className="w-full bg-primary text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={18} />
                  Add to Cart
                </button>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/shop" className="btn-primary inline-block">
            View All Products
          </Link>
        </div>
      </div>
    </section>
  )
}
