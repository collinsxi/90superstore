import { MessageCircle, Mail, Clock, Zap } from "lucide-react"

export default function CustomerSupportCenter() {
  return (
    <section className="py-16 bg-blue-50 border-t border-b border-primary/20">
      <div className="container-full">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">We're Here to Help</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* WhatsApp Support */}
            <div className="bg-white border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <MessageCircle className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">WhatsApp Support</h3>
              <p className="text-sm text-muted-foreground mb-4">Chat directly with our team</p>
              <a
                href="https://wa.me/2348135642177"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary font-bold hover:underline text-sm"
              >
                Message Now →
              </a>
            </div>

            {/* Email Support */}
            <div className="bg-white border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <Mail className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">Email Support</h3>
              <p className="text-sm text-muted-foreground mb-4">Detailed assistance within 2 hours</p>
              <a href="mailto:90Superstore@gmail.com" className="text-primary font-bold hover:underline text-sm">
                Send Email →
              </a>
            </div>

            {/* Working Hours */}
            <div className="bg-white border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <Clock className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">Working Hours</h3>
              <p className="text-sm text-muted-foreground mb-4">Mon-Fri: 9AM-9PM (WAT)</p>
              <p className="text-xs text-muted-foreground">WhatsApp 24/7</p>
            </div>

            {/* Fast Response */}
            <div className="bg-white border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <Zap className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">Quick Response</h3>
              <p className="text-sm text-muted-foreground mb-4">We reply within 30 minutes</p>
              <p className="text-xs text-primary font-semibold">✓ Guaranteed</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
