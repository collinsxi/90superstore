'use client'

import Header from '@/components/header'
import Footer from '@/components/footer'
import { Star, ShoppingCart, Heart, Share2 } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'
import { artProducts } from '@/lib/art-products'

export default function ArtProductPage({ params }: { params: { id: string } }) {
  const product = artProducts.find(p => p.id === params.id)
  const [quantity, setQuantity] = useState(1)
  const [selectedSize, setSelectedSize] = useState(product?.sizes[0].name || '')
  const [selectedFrame, setSelectedFrame] = useState(product?.frames[0].name || '')
  const [liked, setLiked] = useState(false)
  const [cartMessage, setCartMessage] = useState('')

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container-full py-20 text-center">
          <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
          <Link href="/amazing-art" className="text-primary hover:underline">
            Back to Gallery
          </Link>
        </main>
        <Footer />
      </div>
    )
  }

  const selectedSizeData = product.sizes.find(s => s.name === selectedSize)
  const selectedFrameData = product.frames.find(f => f.name === selectedFrame)
  const finalPrice = (selectedSizeData?.price || 0) + (selectedFrameData?.price || 0)

  const handleAddToCart = () => {
    setCartMessage(`Added "${product.title}" (${selectedSize}, ${selectedFrame}) to cart!`)
    setTimeout(() => setCartMessage(''), 3000)
  }

  const relatedArtworks = artProducts.filter(p => p.id !== product.id).slice(0, 3)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-primary">Home</Link>
          <span>/</span>
          <Link href="/amazing-art" className="hover:text-primary">Amazing Art</Link>
          <span>/</span>
          <span className="text-foreground">{product.title}</span>
        </div>

        {/* Product Details */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          {/* Images */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-gray-100 to-gray-200 h-96 md:h-[500px] rounded-xl overflow-hidden flex items-center justify-center">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              {product.images.map((img, idx) => (
                <div
                  key={idx}
                  className="bg-gray-100 h-24 rounded-lg overflow-hidden cursor-pointer hover:ring-2 ring-primary transition"
                >
                  <img src={img} alt={`View ${idx + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Header */}
            <div>
              <p className="text-primary font-semibold mb-2">by {product.artist}</p>
              <h1 className="text-3xl md:text-4xl font-bold mb-4 text-balance">{product.title}</h1>
              
              <div className="flex items-center gap-4">
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={i < Math.floor(product.rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">({product.reviews} reviews)</span>
              </div>
            </div>

            {/* Price */}
            <div className="space-y-2 py-4 border-y">
              <p className="text-sm text-muted-foreground">Starting from</p>
              <p className="text-4xl font-bold text-primary">₦{finalPrice.toLocaleString()}</p>
              <p className="text-sm text-green-600 font-semibold">In Stock</p>
            </div>

            {/* Size Selector */}
            <div>
              <label className="block font-semibold mb-3">Select Size:</label>
              <div className="grid grid-cols-3 gap-3">
                {product.sizes.map(size => (
                  <button
                    key={size.name}
                    onClick={() => setSelectedSize(size.name)}
                    className={`p-3 rounded-lg border-2 transition font-medium ${
                      selectedSize === size.name
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-gray-200 hover:border-primary'
                    }`}
                  >
                    {size.name}
                    <br />
                    <span className="text-xs">₦{size.price.toLocaleString()}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Frame Selector */}
            <div>
              <label className="block font-semibold mb-3">Select Frame:</label>
              <div className="space-y-2">
                {product.frames.map(frame => (
                  <button
                    key={frame.name}
                    onClick={() => setSelectedFrame(frame.name)}
                    className={`w-full p-3 rounded-lg border-2 transition text-left ${
                      selectedFrame === frame.name
                        ? 'border-primary bg-primary/10'
                        : 'border-gray-200 hover:border-primary'
                    }`}
                  >
                    <span className="font-medium">{frame.name}</span>
                    {frame.price > 0 && <span className="text-primary font-semibold ml-2">+₦{frame.price.toLocaleString()}</span>}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="block font-semibold mb-3">Quantity:</label>
              <div className="flex items-center gap-3 w-fit">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-100"
                >
                  −
                </button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-100"
                >
                  +
                </button>
              </div>
            </div>

            {/* Cart Message */}
            {cartMessage && (
              <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
                {cartMessage}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-primary text-white py-4 rounded-lg font-bold hover:bg-blue-700 transition flex items-center justify-center gap-2"
              >
                <ShoppingCart size={20} />
                Add to Cart
              </button>
              <button
                onClick={() => setLiked(!liked)}
                className={`w-12 h-12 rounded-lg border-2 flex items-center justify-center transition ${
                  liked ? 'bg-red-50 border-red-300 text-red-600' : 'border-gray-300'
                }`}
              >
                <Heart size={20} fill={liked ? 'currentColor' : 'none'} />
              </button>
            </div>

            {/* Shipping Info */}
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg space-y-2">
              <p className="font-semibold text-blue-900">Shipping & Delivery</p>
              <p className="text-sm text-blue-800">✓ Free delivery nationwide (1-5 days)</p>
              <p className="text-sm text-blue-800">✓ Carefully packaged with tracking</p>
              <p className="text-sm text-blue-800">✓ Return within 7 days if unsatisfied</p>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="border-y py-12 mb-20">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-bold mb-4">About This Artwork</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">{product.description}</p>
              <p className="text-muted-foreground leading-relaxed">{product.details}</p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-4">Product Specifications</h2>
              <ul className="space-y-3">
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Category:</span>
                  <span className="font-semibold">{product.category}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Artist:</span>
                  <span className="font-semibold">{product.artist}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Printing:</span>
                  <span className="font-semibold">HD Quality Matte</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Stock Status:</span>
                  <span className="font-semibold text-green-600">In Stock</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Frequently Asked Questions */}
        <div className="mb-20">
          <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              { q: 'What paper quality is used?', a: 'Premium 260gsm matte paper for rich colors and durability.' },
              { q: 'How long does delivery take?', a: 'Nationwide delivery within 1-5 working days.' },
              { q: 'Can I customize the size?', a: 'Yes, we offer A4, A3, and A2 sizes. Custom sizes available on request.' },
              { q: 'Are frames included?', a: 'Frames are optional add-ons. Choose Print Only or select a frame option.' },
            ].map((item, idx) => (
              <details key={idx} className="bg-gray-50 p-4 rounded-lg cursor-pointer hover:bg-gray-100 transition">
                <summary className="font-semibold">{item.q}</summary>
                <p className="text-muted-foreground mt-2">{item.a}</p>
              </details>
            ))}
          </div>
        </div>

        {/* Related Products */}
        <div>
          <h2 className="text-2xl font-bold mb-8">More Artwork</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {relatedArtworks.map(art => (
              <Link key={art.id} href={`/art/${art.id}`}>
                <div className="group cursor-pointer">
                  <div className="bg-gray-100 h-64 rounded-lg overflow-hidden mb-4">
                    <img
                      src={art.image}
                      alt={art.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <h3 className="font-semibold group-hover:text-primary transition">{art.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{art.artist}</p>
                  <p className="text-primary font-bold">₦{art.basePrice.toLocaleString()}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
