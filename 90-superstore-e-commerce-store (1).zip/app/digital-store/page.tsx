"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Download, Music, FileText, BookOpen, Code, Video, Zap } from "lucide-react"
import Link from "next/link"

const digitalProducts = [
  {
    id: "d1",
    name: "E-book: Complete Business Guide 2025",
    price: 1999,
    oldPrice: 3999,
    icon: BookOpen,
    format: "PDF",
    description: "Comprehensive guide to starting and scaling your online business",
  },
  {
    id: "d2",
    name: "AI Prompts Pack (100+ Ready-to-Use)",
    price: 2999,
    oldPrice: 4999,
    icon: Code,
    format: "ZIP",
    description: "Pre-built prompts for ChatGPT, Claude, and other AI tools",
  },
  {
    id: "d3",
    name: "Digital Marketing Templates",
    price: 3999,
    oldPrice: 5999,
    icon: FileText,
    format: "ZIP",
    description: "Canva templates, email templates, social media graphics",
  },
  {
    id: "d4",
    name: "Royalty-Free Music Collection (50 Tracks)",
    price: 1499,
    oldPrice: 2999,
    icon: Music,
    format: "ZIP",
    description: "High-quality background music for videos and projects",
  },
  {
    id: "d5",
    name: "Video Tutorial: Content Creation Mastery",
    price: 4999,
    oldPrice: 7999,
    icon: Video,
    format: "MP4",
    description: "Learn professional video creation and editing techniques",
  },
  {
    id: "d6",
    name: "Quick Start: Social Media Growth Guide",
    price: 999,
    oldPrice: 1999,
    icon: Zap,
    format: "PDF",
    description: "Proven strategies to grow your TikTok, Instagram, and YouTube",
  },
]

export default function DigitalStorePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Digital Store</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Instant downloads. No waiting. Digital products delivered to your inbox immediately after purchase.
          </p>
          <div className="inline-block bg-primary/10 border border-primary rounded-lg px-4 py-2 mb-8">
            <p className="text-primary font-semibold">Instant Access After Payment</p>
          </div>
        </div>

        {/* Digital Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {digitalProducts.map((product) => {
            const IconComponent = product.icon
            return (
              <div
                key={product.id}
                className="border border-border rounded-lg p-6 hover:shadow-lg hover:border-primary transition"
              >
                <div className="mb-4 flex items-start justify-between">
                  <IconComponent className="text-primary" size={32} />
                  <span className="bg-primary text-white text-xs px-2 py-1 rounded font-semibold">
                    {product.format}
                  </span>
                </div>
                <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">{product.description}</p>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-2xl font-bold text-primary">₦{product.price.toLocaleString()}</span>
                  <span className="text-sm text-muted-foreground line-through">
                    ₦{product.oldPrice.toLocaleString()}
                  </span>
                </div>
                <button className="w-full bg-primary text-white py-2 rounded-lg font-semibold hover:opacity-90 transition flex items-center justify-center gap-2">
                  <Download size={18} />
                  Buy & Download Now
                </button>
              </div>
            )
          })}
        </div>

        {/* Trust Section */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-8 mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">Why Buy Digital Products from Us?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Zap className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">Instant Download</h3>
              <p className="text-muted-foreground text-sm">Get access immediately after successful payment</p>
            </div>
            <div className="text-center">
              <FileText className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">Lifetime Access</h3>
              <p className="text-muted-foreground text-sm">Download anytime from your email receipt</p>
            </div>
            <div className="text-center">
              <Music className="text-primary mx-auto mb-3" size={32} />
              <h3 className="font-bold mb-2">High Quality</h3>
              <p className="text-muted-foreground text-sm">Premium, professionally created content</p>
            </div>
          </div>
        </div>

        {/* Return to Store */}
        <div className="text-center">
          <Link href="/shop" className="text-primary font-semibold hover:underline">
            ← Back to Physical Products Store
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  )
}
