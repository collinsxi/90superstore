import Header from "@/components/header"
import Footer from "@/components/footer"
import { CheckCircle, X, Clock, MessageCircle } from "lucide-react"

export default function RefundPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="text-4xl font-bold mb-8">Refund & Return Policy</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Not satisfied? We've got you covered. Fast, hassle-free returns.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Clock className="text-primary" />
              7-Day Return Window
            </h2>
            <div className="bg-blue-50 border border-primary/20 rounded-lg p-6">
              <p className="text-lg font-bold mb-2">Return any physical product within 7 days of delivery</p>
              <p className="text-muted-foreground">No questions asked. Full refund to your original payment method.</p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Eligible for Refund ✓</h2>
            <ul className="space-y-3">
              {[
                "Product is damaged or defective",
                "Wrong item was delivered",
                "Item doesn't match description",
                "Changed your mind (within 7 days)",
                "Item never arrived",
              ].map((item, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <CheckCircle className="text-green-500 flex-shrink-0 mt-0.5" size={20} />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">NOT Eligible for Refund ✗</h2>
            <ul className="space-y-3">
              {[
                "Item used extensively or worn out",
                "Item damaged by customer (non-defect)",
                "Original packaging is completely destroyed",
                "Digital products downloaded (no refunds on digital goods)",
                "Custom or personalized items",
              ].map((item, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <X className="text-red-500 flex-shrink-0 mt-0.5" size={20} />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">How to Return an Item</h2>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-start gap-3 mb-3">
                  <span className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">
                    1
                  </span>
                  <div>
                    <p className="font-bold">Contact Us</p>
                    <p className="text-sm text-muted-foreground">
                      Message us via WhatsApp or email with your order number
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-start gap-3 mb-3">
                  <span className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">
                    2
                  </span>
                  <div>
                    <p className="font-bold">Get Return Address</p>
                    <p className="text-sm text-muted-foreground">We'll send you the return shipping address</p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-start gap-3 mb-3">
                  <span className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">
                    3
                  </span>
                  <div>
                    <p className="font-bold">Ship Back</p>
                    <p className="text-sm text-muted-foreground">Pack carefully and ship. Include your order number</p>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-start gap-3 mb-3">
                  <span className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">
                    4
                  </span>
                  <div>
                    <p className="font-bold">Get Your Refund</p>
                    <p className="text-sm text-muted-foreground">
                      After we receive & verify, refund within 24-48 hours
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Special Cases</h2>
            <div className="space-y-4">
              <div>
                <p className="font-bold mb-2">Damaged or Defective Product?</p>
                <p className="text-muted-foreground">
                  Send photos and we'll issue a replacement or refund immediately. No return shipping needed.
                </p>
              </div>
              <div>
                <p className="font-bold mb-2">Wrong Item Delivered?</p>
                <p className="text-muted-foreground">
                  We'll send the correct item right away or refund you. Your choice.
                </p>
              </div>
              <div>
                <p className="font-bold mb-2">Never Arrived?</p>
                <p className="text-muted-foreground">
                  Lost package? We'll replace it or refund you within 48 hours (we're insured).
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Digital Products Policy</h2>
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
              <p className="font-bold mb-2">⚠️ NO REFUNDS on digital products after download</p>
              <p className="text-muted-foreground">
                Once you download eBooks, templates, AI prompts, etc., they cannot be refunded. Preview before
                purchasing.
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <MessageCircle className="text-primary" />
              Need Help With Your Return?
            </h2>
            <div className="bg-primary text-white p-6 rounded-lg">
              <p className="mb-4 font-semibold">We're here to make it easy. No long phone calls, no runaround.</p>
              <p className="mb-4">
                Average resolution time: <strong>24-48 hours</strong>
              </p>
              <div className="space-y-2">
                <a href="https://wa.me/2348135642177" className="block underline hover:opacity-80">
                  💬 Chat on WhatsApp
                </a>
                <a href="mailto:90Superstore@gmail.com" className="block underline hover:opacity-80">
                  📧 Email us
                </a>
              </div>
            </div>
          </section>

          <section className="bg-gray-50 p-6 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Last updated:</strong> November 2025 | This policy applies to all orders placed after January 1,
              2025
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}
