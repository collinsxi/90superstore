'use client'

import { useState } from 'react'
import Link from 'next/link'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { ChevronRight, Send } from 'lucide-react'
import { artProducts } from '@/lib/art-products'

const categories = ['All', 'Framed Art', 'Wall Posters', 'Digital Downloads', 'Custom Frame Orders']

export default function AmazingArt() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [customFormData, setCustomFormData] = useState({
    name: '',
    email: '',
    message: '',
    file: null as File | null,
  })
  const [customFormSuccess, setCustomFormSuccess] = useState(false)

  const filteredArtworks = selectedCategory === 'All'
    ? artProducts
    : artProducts.filter(art => art.category === selectedCategory)

  const handleCustomFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setCustomFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setCustomFormData(prev => ({ ...prev, file: e.target.files![0] }))
    }
  }

  const handleCustomFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setCustomFormSuccess(true)
    setCustomFormData({ name: '', email: '', message: '', file: null })
    setTimeout(() => setCustomFormSuccess(false), 3000)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-16">
          <div className="container-full">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Amazing Art Gallery</h1>
              <p className="text-lg md:text-xl text-blue-100 mb-6">
                Discover stunning original artwork, curated designs, and custom creations to elevate your space.
              </p>
              <div className="flex flex-wrap gap-3">
                <p className="text-blue-100 flex items-center gap-1">
                  <ChevronRight size={16} /> Premium Quality Prints
                </p>
                <p className="text-blue-100 flex items-center gap-1">
                  <ChevronRight size={16} /> Fast Delivery Nationwide
                </p>
                <p className="text-blue-100 flex items-center gap-1">
                  <ChevronRight size={16} /> Custom Orders Available
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Category Filters */}
        <section className="bg-white border-b py-8">
          <div className="container-full">
            <div className="flex flex-wrap gap-3">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-6 py-2 rounded-full font-semibold transition ${
                    selectedCategory === cat
                      ? 'bg-primary text-white'
                      : 'bg-gray-100 text-foreground hover:bg-gray-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Gallery Grid */}
        <section className="container-full py-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArtworks.map(art => (
              <Link key={art.id} href={`/art/${art.id}`}>
                <div className="group">
                  <div className="bg-gradient-to-br from-gray-100 to-gray-200 h-72 rounded-lg overflow-hidden mb-4 relative">
                    <img
                      src={art.image}
                      alt={art.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition duration-300 flex items-end p-4">
                      <button className="bg-primary text-white px-4 py-2 rounded-lg font-semibold opacity-0 group-hover:opacity-100 transition translate-y-4 group-hover:translate-y-0 duration-300 w-full text-center">
                        View Details
                      </button>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold group-hover:text-primary transition">{art.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{art.artist}</p>
                  <div className="flex items-center justify-between">
                    <p className="text-primary font-bold text-lg">₦{art.basePrice.toLocaleString()}</p>
                    <span className="text-sm bg-amber-100 text-amber-800 px-2 py-1 rounded">
                      ★ {art.rating}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Custom Order Section */}
        <section className="bg-gradient-to-br from-purple-50 to-blue-50 py-16 border-t">
          <div className="container-full">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold mb-2 text-center">Custom Artwork Orders</h2>
              <p className="text-muted-foreground text-center mb-12">
                Have a unique vision? Upload your artwork or design, and we'll bring it to life with premium framing and printing options.
              </p>

              <div className="bg-white rounded-xl shadow-lg p-8 md:p-12">
                <form onSubmit={handleCustomFormSubmit} className="space-y-6">
                  {/* Name */}
                  <div>
                    <label className="block font-semibold mb-2">Your Name</label>
                    <input
                      type="text"
                      name="name"
                      value={customFormData.name}
                      onChange={handleCustomFormChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="John Doe"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block font-semibold mb-2">Email Address</label>
                    <input
                      type="email"
                      name="email"
                      value={customFormData.email}
                      onChange={handleCustomFormChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="john@example.com"
                    />
                  </div>

                  {/* File Upload */}
                  <div>
                    <label className="block font-semibold mb-2">Upload Your Design</label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-primary transition">
                      <input
                        type="file"
                        onChange={handleFileUpload}
                        accept="image/*"
                        className="hidden"
                        id="file-upload"
                      />
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <p className="font-semibold mb-2">{customFormData.file ? customFormData.file.name : 'Click to upload or drag and drop'}</p>
                        <p className="text-sm text-muted-foreground">PNG, JPG, GIF up to 50MB</p>
                      </label>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block font-semibold mb-2">Your Message</label>
                    <textarea
                      name="message"
                      value={customFormData.message}
                      onChange={handleCustomFormChange}
                      required
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Tell us about your custom artwork idea, preferred size, framing style, etc."
                    />
                  </div>

                  {/* Success Message */}
                  {customFormSuccess && (
                    <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
                      ✓ Thank you! We've received your custom order request. We'll contact you within 24 hours.
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full bg-primary text-white py-4 rounded-lg font-bold hover:bg-blue-700 transition flex items-center justify-center gap-2"
                  >
                    <Send size={20} />
                    Submit Custom Order Request
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Our Art */}
        <section className="container-full py-16 border-t">
          <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Our Artwork</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { title: 'Premium Quality', desc: 'HD printing on high-grade matte paper' },
              { title: 'Fast Delivery', desc: 'Nationwide delivery within 1-5 days' },
              { title: 'Expert Framing', desc: 'Professional framing with multiple options' },
              { title: 'Custom Orders', desc: 'Bring your vision to life with custom art' },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">{idx + 1}</span>
                </div>
                <h3 className="font-bold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
