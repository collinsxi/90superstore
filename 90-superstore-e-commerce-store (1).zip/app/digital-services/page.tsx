'use client'

import { useState } from 'react'
import Link from 'next/link'
import Header from '@/components/header'
import Footer from '@/components/footer'
import { Code2, Globe, Zap, RefreshCw, ArrowRight, Check } from 'lucide-react'

const services = [
  {
    id: 1,
    title: 'Starter Business Website',
    icon: <Globe className="w-12 h-12" />,
    description: 'Perfect for small businesses and startups looking to establish an online presence.',
    features: [
      '5-8 Pages (Home, About, Services, Gallery, Contact)',
      'Mobile Responsive Design',
      'SEO Optimized',
      'Contact Form Integration',
      'Basic Analytics',
    ],
    price: '₦150,000',
    duration: '7-10 days',
    color: 'from-blue-500 to-blue-600',
  },
  {
    id: 2,
    title: 'E-commerce Website',
    icon: <Zap className="w-12 h-12" />,
    description: 'Complete online store with product catalog, shopping cart, and payment integration.',
    features: [
      'Product Management System',
      'Shopping Cart & Checkout',
      'Payment Gateway Integration',
      'Inventory Management',
      'Order Tracking',
      'Admin Dashboard',
      '24/7 Support',
    ],
    price: '₦300,000',
    duration: '14-21 days',
    color: 'from-purple-500 to-purple-600',
  },
  {
    id: 3,
    title: 'Personal Brand Website',
    icon: <Code2 className="w-12 h-12" />,
    description: 'Showcase your portfolio, services, and build your personal brand online.',
    features: [
      'Portfolio Gallery',
      'Blog Section',
      'Service Showcase',
      'Client Testimonials',
      'Social Media Integration',
      'Email Newsletter',
    ],
    price: '₦120,000',
    duration: '5-7 days',
    color: 'from-green-500 to-green-600',
  },
  {
    id: 4,
    title: 'Website Redesign',
    icon: <RefreshCw className="w-12 h-12" />,
    description: 'Revamp your existing website with modern design and improved functionality.',
    features: [
      'Full UI/UX Redesign',
      'Performance Optimization',
      'Modern Design Trends',
      'Speed Improvement',
      'SEO Enhancement',
      'Migration Assistance',
    ],
    price: '₦200,000+',
    duration: '10-14 days',
    color: 'from-orange-500 to-orange-600',
  },
]

const process = [
  {
    step: 1,
    title: 'Consultation',
    description: 'We discuss your business goals, target audience, and specific requirements.',
  },
  {
    step: 2,
    title: 'Design & Planning',
    description: 'Our team creates wireframes and designs that align with your vision.',
  },
  {
    step: 3,
    title: 'Development',
    description: 'We build your website with clean code and best practices.',
  },
  {
    step: 4,
    title: 'Testing & Launch',
    description: 'Thorough testing followed by deployment and optimization.',
  },
]

export default function DigitalServices() {
  const [selectedService, setSelectedService] = useState(null)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-16">
          <div className="container-full">
            <div className="max-w-3xl">
              <h1 className="text-5xl font-bold mb-4 text-balance">Digital Services</h1>
              <p className="text-xl text-blue-100 mb-6">
                We build modern, professional websites and digital solutions for businesses, brands, and individuals.
              </p>
              <p className="text-blue-100">
                Whether you need a simple business website or a complex e-commerce platform, we have the expertise to bring your vision to life.
              </p>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16">
          <div className="container-full">
            <div className="grid md:grid-cols-2 gap-8">
              {services.map(service => (
                <div
                  key={service.id}
                  className="group bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 flex flex-col"
                >
                  {/* Color Header */}
                  <div className={`h-24 bg-gradient-to-r ${service.color} flex items-center justify-center text-white`}>
                    {service.icon}
                  </div>

                  {/* Content */}
                  <div className="p-8 flex-1 flex flex-col">
                    <h3 className="text-2xl font-bold mb-2 text-foreground">{service.title}</h3>
                    <p className="text-muted-foreground mb-6">{service.description}</p>

                    {/* Features List */}
                    <ul className="space-y-2 mb-6 flex-1">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <Check size={20} className="text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Price & Timeline */}
                    <div className="border-t pt-6 mb-6">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">Starting From</p>
                          <p className="text-2xl font-bold text-primary">{service.price}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground mb-1">Timeline</p>
                          <p className="font-semibold text-foreground">{service.duration}</p>
                        </div>
                      </div>
                    </div>

                    {/* Button */}
                    <button
                      onClick={() => setSelectedService(service.id)}
                      className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition flex items-center justify-center gap-2 group/btn"
                    >
                      Request Service
                      <ArrowRight size={20} className="group-hover/btn:translate-x-1 transition" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Process */}
        <section className="py-16 bg-gray-50">
          <div className="container-full">
            <h2 className="text-4xl font-bold text-center mb-12">Our Process</h2>
            <div className="grid md:grid-cols-4 gap-8">
              {process.map((item, idx) => (
                <div key={item.step} className="flex flex-col items-center">
                  {/* Step Number */}
                  <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-center">{item.title}</h3>
                  <p className="text-muted-foreground text-center text-sm">{item.description}</p>

                  {/* Connector Line */}
                  {idx < process.length - 1 && (
                    <div className="hidden md:block absolute left-1/2 w-12 h-1 bg-primary mt-24"></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 bg-white">
          <div className="container-full">
            <h2 className="text-4xl font-bold text-center mb-12">Why Choose 90SUPERSTORE Digital Services</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">⚡</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Fast Delivery</h3>
                <p className="text-muted-foreground">We deliver projects on time without compromising quality.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">🎯</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Expert Team</h3>
                <p className="text-muted-foreground">Experienced developers and designers focused on your success.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">💬</span>
                </div>
                <h3 className="text-xl font-bold mb-2">24/7 Support</h3>
                <p className="text-muted-foreground">Dedicated support available through WhatsApp and email.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <div className="container-full text-center">
            <h2 className="text-4xl font-bold mb-4">Ready to Start Your Digital Project?</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Get in touch with our team today to discuss your project requirements and get a free consultation.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 bg-white text-blue-600 px-8 py-4 rounded-lg font-bold hover:bg-blue-50 transition"
              >
                Contact Us
                <ArrowRight size={20} />
              </Link>
              <a
                href="https://wa.me/2348135642177"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white hover:text-blue-600 transition"
              >
                Chat on WhatsApp
                <ArrowRight size={20} />
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
