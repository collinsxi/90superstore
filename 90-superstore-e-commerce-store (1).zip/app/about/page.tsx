import Header from "@/components/header"
import Footer from "@/components/footer"
import { CheckCircle, Globe, Zap, Heart, Users, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-4xl mx-auto space-y-16">
          {/* Hero Section */}
          <section className="text-center space-y-4 mb-12">
            <h1 className="text-5xl font-bold">About 90SUPERSTORE</h1>
            <p className="text-xl text-muted-foreground">
              Where Quality, Affordability, and Trust Meet Global Shopping
            </p>
          </section>

          {/* Our Story */}
          <section className="space-y-6">
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <Heart className="text-primary" />
              Our Story
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              90SUPERSTORE is a next-generation online marketplace designed to bring Nigerians and global customers
              access to world-class products at prices that don't break the bank. We started with a simple mission: make
              shopping easier, faster, and more affordable for everyone.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              In today's fast-paced world, people deserve access to quality products from China, USA, Europe, and
              trusted local suppliers without paying premium prices. That's exactly what we do — we bridge the gap
              between global quality and local affordability.
            </p>
          </section>

          {/* What We Do */}
          <section className="space-y-6">
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <Globe className="text-primary" />
              What We Do
            </h2>
            <p className="text-muted-foreground mb-6">
              We're not just an online store. We're a complete shopping ecosystem offering:
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border border-border rounded-lg p-6 space-y-3">
                <h3 className="font-bold text-lg">Physical Products</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>✓ Electronics & Gadgets</li>
                  <li>✓ Fashion & Accessories</li>
                  <li>✓ Home & Kitchen Items</li>
                  <li>✓ Health & Beauty</li>
                  <li>✓ Fitness & Wellness</li>
                </ul>
              </div>
              <div className="border border-border rounded-lg p-6 space-y-3">
                <h3 className="font-bold text-lg">Digital Products</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>✓ eBooks & Guides</li>
                  <li>✓ AI Prompts & Templates</li>
                  <li>✓ Online Courses</li>
                  <li>✓ Video Content</li>
                  <li>✓ Instant Downloads</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Our Focus */}
          <section className="space-y-6">
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <Zap className="text-primary" />
              What We're Focused On
            </h2>
            <div className="space-y-4">
              {[
                {
                  icon: Zap,
                  title: "Lightning-Fast Delivery",
                  desc: "1-5 days nationwide in Nigeria. We know you value your time.",
                },
                {
                  icon: TrendingUp,
                  title: "Honest, Transparent Pricing",
                  desc: "No hidden fees. No surprise charges. What you see is what you pay.",
                },
                {
                  icon: CheckCircle,
                  title: "100% Quality Products",
                  desc: "Every item is carefully sourced and verified before reaching you.",
                },
                {
                  icon: Heart,
                  title: "Safe & Secure Payments",
                  desc: "SSL encryption. PCI-DSS compliant. Your data is protected.",
                },
                {
                  icon: Users,
                  title: "Real Customer Service",
                  desc: "No bots. Real people. Support 24/7 via WhatsApp and email.",
                },
                {
                  icon: Globe,
                  title: "Global + Local Excellence",
                  desc: "Best products from worldwide. Powered by Nigerian excellence.",
                },
              ].map((item, i) => {
                const IconComponent = item.icon
                return (
                  <div key={i} className="flex gap-4 items-start">
                    <IconComponent className="text-primary flex-shrink-0 mt-1" size={24} />
                    <div>
                      <h3 className="font-bold mb-1">{item.title}</h3>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          {/* Our Mission & Vision */}
          <section className="grid md:grid-cols-2 gap-8">
            <div className="bg-primary text-white rounded-lg p-8 space-y-4">
              <h3 className="text-2xl font-bold">Our Mission</h3>
              <p className="leading-relaxed text-blue-50">
                To make shopping easier, faster, and more affordable for everyone. We connect Nigeria and the world
                through reliable e-commerce powered by trust, transparency, and quality.
              </p>
            </div>
            <div className="bg-secondary text-white rounded-lg p-8 space-y-4">
              <h3 className="text-2xl font-bold">Our Vision</h3>
              <p className="leading-relaxed text-blue-50">
                To be the most trusted online marketplace in Africa—where anyone can find world-class products at
                affordable prices, backed by exceptional customer service.
              </p>
            </div>
          </section>

          {/* Why Choose Us */}
          <section className="space-y-6">
            <h2 className="text-3xl font-bold">Why Choose 90SUPERSTORE?</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-blue-50 border border-primary/20 rounded-lg p-6 space-y-3">
                <p className="text-3xl font-bold text-primary">1000+</p>
                <p className="font-bold">Satisfied Customers</p>
                <p className="text-sm text-muted-foreground">Real people, real reviews, real trust</p>
              </div>
              <div className="bg-blue-50 border border-primary/20 rounded-lg p-6 space-y-3">
                <p className="text-3xl font-bold text-primary">5,000+</p>
                <p className="font-bold">Products Available</p>
                <p className="text-sm text-muted-foreground">Physical & digital, always updated</p>
              </div>
              <div className="bg-blue-50 border border-primary/20 rounded-lg p-6 space-y-3">
                <p className="text-3xl font-bold text-primary">4.8★</p>
                <p className="font-bold">Average Rating</p>
                <p className="text-sm text-muted-foreground">Based on real customer feedback</p>
              </div>
            </div>
          </section>

          {/* Values */}
          <section className="space-y-6">
            <h2 className="text-3xl font-bold">Our Core Values</h2>
            <div className="space-y-4">
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-primary">
                <p className="font-bold mb-2">✓ Integrity</p>
                <p className="text-muted-foreground">
                  We're honest about our products, prices, and service. No gimmicks.
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-primary">
                <p className="font-bold mb-2">✓ Excellence</p>
                <p className="text-muted-foreground">
                  Every product, every interaction, every service goes through quality checks.
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-primary">
                <p className="font-bold mb-2">✓ Customer-First</p>
                <p className="text-muted-foreground">Your satisfaction isn't just important—it's everything we do.</p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-primary">
                <p className="font-bold mb-2">✓ Innovation</p>
                <p className="text-muted-foreground">
                  We continuously evolve to give you the best shopping experience.
                </p>
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="bg-gradient-to-r from-primary to-blue-600 text-white rounded-lg p-12 text-center space-y-6">
            <h2 className="text-3xl font-bold">Ready to Shop With Confidence?</h2>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Join thousands of happy customers who've discovered better shopping at 90SUPERSTORE.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Link
                href="/shop"
                className="bg-white text-primary font-bold px-8 py-3 rounded-lg hover:opacity-90 transition"
              >
                Start Shopping Now
              </Link>
              <Link
                href="/contact"
                className="border-2 border-white text-white font-bold px-8 py-3 rounded-lg hover:bg-white hover:text-primary transition"
              >
                Get in Touch
              </Link>
            </div>
          </section>

          {/* Contact Section */}
          <section className="text-center space-y-4 py-8 border-t border-gray-200">
            <h2 className="text-2xl font-bold">Questions? We're Here for You.</h2>
            <div className="flex gap-4 justify-center flex-wrap">
              <a href="https://wa.me/2348135642177" className="text-primary font-bold hover:underline">
                💬 WhatsApp: 08135642177
              </a>
              <a href="mailto:90Superstore@gmail.com" className="text-primary font-bold hover:underline">
                📧 90Superstore@gmail.com
              </a>
            </div>
            <p className="text-muted-foreground text-sm">Response time: Less than 30 minutes</p>
          </section>

          <p className="text-center text-muted-foreground font-semibold">Shop with Confidence. Shop 90SUPERSTORE. 🚀</p>
        </div>
      </main>
      <Footer />
    </div>
  )
}
