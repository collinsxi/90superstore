"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { useState } from "react"
import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"

const products = [
  {
    id: 1,
    name: "Premium Wireless Earbuds",
    price: "₦8,999",
    originalPrice: "₦12,999",
    rating: 4.8,
    reviews: 234,
    image: "/wireless-earbuds.png",
    category: "accessories",
  },
  // Add more products as needed
]

export default function ShopPage() {
  const [sortBy, setSortBy] = useState("newest")

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        <h1 className="text-4xl font-bold mb-8">Shop All Products</h1>

        <div className="flex gap-6">
          {/* Sidebar Filters */}
          <aside className="hidden lg:block w-64 space-y-6">
            <div>
              <h3 className="font-bold mb-4">Categories</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-primary">
                    Phones & Gadgets
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-primary">
                    Accessories
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-primary">
                    Electronics
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Price Range</h3>
              <input type="range" className="w-full" />
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-8">
              <p className="text-muted-foreground">Showing 1-12 products</p>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg"
              >
                <option value="newest">Newest</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <Link key={product.id} href={`/product/${product.id}`} className="card-product group overflow-hidden">
                  <div className="relative overflow-hidden bg-gray-100 h-48">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold line-clamp-2 mb-2">{product.name}</h3>
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={
                            i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                          }
                        />
                      ))}
                    </div>
                    <div className="flex gap-2 mb-3">
                      <span className="font-bold text-primary">{product.price}</span>
                      <span className="line-through text-muted-foreground">{product.originalPrice}</span>
                    </div>
                    <button className="w-full bg-primary text-white py-2 rounded-lg flex items-center justify-center gap-2">
                      <ShoppingCart size={18} />
                      Add
                    </button>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
