"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Star, ShoppingCart, Share2, Heart } from "lucide-react"
import { useState } from "react"

export default function ProductPage({ params }: { params: { id: string } }) {
  const [quantity, setQuantity] = useState(1)
  const [liked, setLiked] = useState(false)

  // Sample product data
  const product = {
    id: params.id,
    name: "Premium Wireless Earbuds with Active Noise Cancellation",
    price: "₦8,999",
    originalPrice: "₦12,999",
    rating: 4.8,
    reviews: 234,
    image: "/wireless-earbuds.png",
    images: ["/wireless-earbuds.png", "/wireless-earbuds-package.jpg", "/wireless-earbuds-details.jpg"],
    description:
      "Experience premium sound quality with our advanced wireless earbuds featuring active noise cancellation technology.",
    features: [
      "Active Noise Cancellation (ANC)",
      "Up to 8 hours battery life",
      "Premium sound quality with bass boost",
      "Comfortable design for all-day wear",
      "Fast charging - 15 minutes for 2 hours",
      "Water-resistant (IPX4 rated)",
      "Bluetooth 5.0 connectivity",
      "Touch controls",
    ],
    inStock: true,
    shipping: "Free delivery nationwide",
  }

  const relatedProducts = [
    { id: 2, name: "Bluetooth Speaker", price: "₦7,999", image: "/audio-speaker.png" },
    { id: 3, name: "Phone Stand Mount", price: "₦1,999", image: "/phone-stand.jpg" },
    { id: 4, name: "USB-C Cable", price: "₦2,999", image: "/usb-cable.png" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="bg-gray-100 h-96 rounded-lg overflow-hidden">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {product.images.map((img, idx) => (
                <div key={idx} className="bg-gray-100 h-24 rounded-lg overflow-hidden cursor-pointer hover:opacity-75">
                  <img src={img || "/placeholder.svg"} alt={`View ${idx + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Title & Rating */}
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      className={i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                    />
                  ))}
                </div>
                <span className="text-muted-foreground">({product.reviews} reviews)</span>
              </div>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <div className="flex items-center gap-4">
                <span className="text-4xl font-bold text-primary">{product.price}</span>
                <span className="text-2xl text-muted-foreground line-through">{product.originalPrice}</span>
              </div>
              <p className="text-lg font-semibold text-green-600">Save 25% today!</p>
            </div>

            {/* Description */}
            <p className="text-muted-foreground text-lg">{product.description}</p>

            {/* Features */}
            <div>
              <h3 className="font-bold mb-3">Key Features:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {product.features.map((feature, idx) => (
                  <li key={idx} className="flex gap-2 text-sm">
                    <span className="text-primary">✓</span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Stock Status */}
            <div className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-full ${product.inStock ? "bg-green-500" : "bg-red-500"}`}></div>
              <span className={product.inStock ? "text-green-600 font-semibold" : "text-red-600 font-semibold"}>
                {product.inStock ? "In Stock" : "Out of Stock"}
              </span>
            </div>

            {/* Quantity & Actions */}
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex items-center border border-border rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 hover:bg-gray-100"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 font-semibold">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="px-4 py-2 hover:bg-gray-100">
                    +
                  </button>
                </div>
                <button className="btn-primary flex-1 flex items-center justify-center gap-2">
                  <ShoppingCart size={20} />
                  Add to Cart
                </button>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setLiked(!liked)}
                  className={`flex-1 py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2 ${
                    liked ? "bg-red-100 text-red-600" : "border-2 border-border hover:border-primary"
                  }`}
                >
                  <Heart size={20} fill={liked ? "currentColor" : "none"} />
                  {liked ? "Saved" : "Save for Later"}
                </button>
                <button className="flex-1 py-3 rounded-lg font-semibold border-2 border-border hover:border-primary transition flex items-center justify-center gap-2">
                  <Share2 size={20} />
                  Share
                </button>
              </div>
            </div>

            {/* Shipping Info */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <p className="font-semibold text-primary mb-2">📦 {product.shipping}</p>
              <p className="text-sm text-muted-foreground">Delivery within 24-48 hours</p>
            </div>

            {/* Trust Badges */}
            <div className="flex gap-4 pt-4 border-t">
              <div className="text-center flex-1">
                <p className="font-bold text-lg">✓</p>
                <p className="text-xs text-muted-foreground">Secure Checkout</p>
              </div>
              <div className="text-center flex-1">
                <p className="font-bold text-lg">✓</p>
                <p className="text-xs text-muted-foreground">Money-Back Guarantee</p>
              </div>
              <div className="text-center flex-1">
                <p className="font-bold text-lg">✓</p>
                <p className="text-xs text-muted-foreground">24/7 Support</p>
              </div>
            </div>
          </div>
        </div>

        {/* Recommended Products */}
        <section className="border-t pt-12">
          <h2 className="text-2xl font-bold mb-8">Frequently Bought Together</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedProducts.map((prod) => (
              <div key={prod.id} className="card-product p-4">
                <div className="bg-gray-100 h-32 rounded-lg mb-4 overflow-hidden">
                  <img src={prod.image || "/placeholder.svg"} alt={prod.name} className="w-full h-full object-cover" />
                </div>
                <h3 className="font-semibold mb-2">{prod.name}</h3>
                <p className="text-primary font-bold mb-3">{prod.price}</p>
                <button className="w-full bg-primary text-white py-2 rounded-lg text-sm font-semibold hover:opacity-90">
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
