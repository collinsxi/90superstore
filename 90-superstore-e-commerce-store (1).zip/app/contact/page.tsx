"use client"

import type React from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Mail, Phone, MessageCircle, Send, Clock, Zap } from "lucide-react"
import { useState } from "react"

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-5xl mx-auto space-y-12">
          {/* Hero */}
          <section className="text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold">Get in Touch</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Questions? Issues? We're here to help. Fast response, real solutions.
            </p>
            <div className="inline-block bg-green-100 text-green-700 px-4 py-2 rounded-lg font-semibold">
              <Zap className="inline mr-2" size={18} />
              We reply in less than 30 minutes
            </div>
          </section>

          {/* Contact Methods Grid */}
          <section className="grid md:grid-cols-3 gap-6">
            {/* WhatsApp */}
            <div className="border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <MessageCircle className="text-primary mx-auto mb-3" size={40} />
              <h3 className="font-bold text-lg mb-2">WhatsApp Business</h3>
              <p className="text-muted-foreground text-sm mb-4">Instant messaging, real-time support</p>
              <a
                href="https://wa.me/2348135642177"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary font-bold hover:underline"
              >
                Chat Now →
              </a>
            </div>

            {/* Email */}
            <div className="border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <Mail className="text-primary mx-auto mb-3" size={40} />
              <h3 className="font-bold text-lg mb-2">Email</h3>
              <p className="text-muted-foreground text-sm mb-4">Detailed inquiries and support</p>
              <a href="mailto:90Superstore@gmail.com" className="text-primary font-bold hover:underline">
                Send Email →
              </a>
            </div>

            {/* Phone */}
            <div className="border border-border rounded-lg p-6 text-center hover:shadow-lg hover:border-primary transition">
              <Phone className="text-primary mx-auto mb-3" size={40} />
              <h3 className="font-bold text-lg mb-2">Call Us</h3>
              <p className="text-muted-foreground text-sm mb-4">Direct phone support available</p>
              <a href="tel:+2348135642177" className="text-primary font-bold hover:underline">
                08135642177 →
              </a>
            </div>
          </section>

          {/* Support Hours */}
          <section className="bg-blue-50 border border-primary/20 rounded-lg p-8">
            <div className="flex items-start gap-4 md:flex-row flex-col">
              <Clock className="text-primary flex-shrink-0" size={32} />
              <div>
                <h3 className="font-bold text-lg mb-2">Support Hours</h3>
                <p className="text-muted-foreground mb-2">
                  <strong>Monday - Friday:</strong> 9:00 AM - 9:00 PM (WAT)
                </p>
                <p className="text-muted-foreground mb-2">
                  <strong>Saturday - Sunday:</strong> 10:00 AM - 6:00 PM (WAT)
                </p>
                <p className="text-muted-foreground">
                  WhatsApp available <strong>24/7</strong> for urgent orders
                </p>
              </div>
            </div>
          </section>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <section className="space-y-6">
              <h2 className="text-2xl font-bold">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Your Name</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full px-4 py-3 border border-border rounded-lg outline-none focus:border-primary transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Email Address</label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    className="w-full px-4 py-3 border border-border rounded-lg outline-none focus:border-primary transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Subject</label>
                  <input
                    type="text"
                    placeholder="How can we help?"
                    className="w-full px-4 py-3 border border-border rounded-lg outline-none focus:border-primary transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Message</label>
                  <textarea
                    placeholder="Tell us what's on your mind..."
                    rows={5}
                    className="w-full px-4 py-3 border border-border rounded-lg outline-none focus:border-primary transition resize-none"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:opacity-90 transition flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  Send Message
                </button>
                {submitted && (
                  <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-center">
                    Thanks! We'll get back to you soon.
                  </div>
                )}
              </form>
            </section>

            {/* FAQ */}
            <section className="space-y-6">
              <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <div className="border border-border rounded-lg p-4">
                  <p className="font-bold mb-2">How fast do you deliver?</p>
                  <p className="text-muted-foreground text-sm">
                    1-3 days in major cities, 3-5 days nationwide. All orders tracked.
                  </p>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <p className="font-bold mb-2">Can I return an item?</p>
                  <p className="text-muted-foreground text-sm">
                    Yes! 7-day return window for physical products. Check our Refund Policy for details.
                  </p>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <p className="font-bold mb-2">Is checkout secure?</p>
                  <p className="text-muted-foreground text-sm">
                    100% secure with SSL encryption. Your payment info is protected.
                  </p>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <p className="font-bold mb-2">Where can I track my order?</p>
                  <p className="text-muted-foreground text-sm">
                    Visit our{" "}
                    <a href="/track-order" className="text-primary font-semibold">
                      Track Order
                    </a>{" "}
                    page anytime.
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* CTA Section */}
          <section className="bg-gradient-to-r from-primary to-blue-600 text-white rounded-lg p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Don't Wait. Reach Out Today.</h2>
            <p className="text-lg mb-8 opacity-90">We're ready to help with your orders, questions, or feedback.</p>
            <div className="flex gap-4 justify-center flex-wrap">
              <a
                href="https://wa.me/2348135642177"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white text-primary font-bold px-8 py-3 rounded-lg hover:opacity-90 transition"
              >
                WhatsApp Now
              </a>
              <a
                href="mailto:90Superstore@gmail.com"
                className="border-2 border-white text-white font-bold px-8 py-3 rounded-lg hover:bg-white hover:text-primary transition"
              >
                Send Email
              </a>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}
