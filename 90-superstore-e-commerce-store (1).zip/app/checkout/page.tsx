"use client"

import type React from "react"

import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import { ArrowLeft, CheckCircle, CreditCard, Banknote } from "lucide-react"
import { useState } from "react"

export default function CheckoutPage() {
  const [step, setStep] = useState<"shipping" | "payment" | "confirmation">("shipping")
  const [paymentMethod, setPaymentMethod] = useState<"card" | "bank" | null>(null)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    cardName: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setStep("payment")
  }

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (paymentMethod) {
      setStep("confirmation")
    }
  }

  const total = 24998

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        {step !== "confirmation" && (
          <Link href="/cart" className="inline-flex items-center gap-2 text-primary hover:underline mb-8">
            <ArrowLeft size={20} />
            Back to Cart
          </Link>
        )}

        <div className="max-w-4xl mx-auto">
          {step === "confirmation" ? (
            // Order Confirmation
            <div className="text-center py-20 space-y-6">
              <div className="flex justify-center mb-6">
                <div className="bg-green-100 p-6 rounded-full">
                  <CheckCircle size={48} className="text-green-600" />
                </div>
              </div>
              <h1 className="text-4xl font-bold">Order Confirmed!</h1>
              <p className="text-xl text-muted-foreground max-w-lg mx-auto">
                Thank you for your purchase. Your order has been successfully placed and will be delivered within 1-5 business days.
              </p>

              <div className="card-product p-8 max-w-md mx-auto">
                <p className="text-sm text-muted-foreground mb-2">Order Number</p>
                <p className="text-2xl font-bold mb-6">#90SS-{Math.random().toString(36).substr(2, 9).toUpperCase()}</p>

                <p className="text-sm text-muted-foreground mb-2">Total Amount</p>
                <p className="text-3xl font-bold text-primary mb-6">₦{total.toLocaleString()}</p>

                <p className="text-sm text-muted-foreground mb-6">
                  A confirmation email has been sent to {formData.email}
                </p>

                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg mb-6">
                  <p className="text-sm text-blue-900">
                    <strong>Tracking:</strong> You'll receive an SMS and email with your tracking number shortly.
                  </p>
                </div>

                <Link href="/" className="block w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition text-center mb-3">
                  Continue Shopping
                </Link>
                <Link href="/track-order" className="block w-full border-2 border-primary text-primary py-3 rounded-lg font-bold hover:bg-primary hover:text-white transition text-center">
                  Track Your Order
                </Link>
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              {/* Main Form */}
              <div className="md:col-span-2">
                {/* Progress Steps */}
                <div className="flex gap-4 mb-8">
                  <div className={`flex-1 h-1 rounded-full ${step === "shipping" || step === "payment" || step === "confirmation" ? "bg-primary" : "bg-gray-200"}`} />
                  <div className={`flex-1 h-1 rounded-full ${step === "payment" || step === "confirmation" ? "bg-primary" : "bg-gray-200"}`} />
                  <div className={`flex-1 h-1 rounded-full ${step === "confirmation" ? "bg-primary" : "bg-gray-200"}`} />
                </div>

                {/* Shipping Form */}
                {step === "shipping" && (
                  <form onSubmit={handleShippingSubmit} className="space-y-6">
                    <h2 className="text-2xl font-bold">Shipping Address</h2>

                    <div className="grid md:grid-cols-2 gap-4">
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        placeholder="First Name"
                        required
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        placeholder="Last Name"
                        required
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>

                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="Email Address"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />

                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="Phone Number"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />

                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Street Address"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />

                    <div className="grid md:grid-cols-2 gap-4">
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="City"
                        required
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                      <input
                        type="text"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        placeholder="State"
                        required
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition"
                    >
                      Continue to Payment
                    </button>
                  </form>
                )}

                {/* Payment Form */}
                {step === "payment" && (
                  <form onSubmit={handlePaymentSubmit} className="space-y-6">
                    <h2 className="text-2xl font-bold">Select Payment Method</h2>

                    <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg mb-6">
                      <p className="text-sm text-blue-900">
                        <strong>Note:</strong> Payment integration coming soon. This is a demo checkout flow.
                      </p>
                    </div>

                    {/* Card Payment */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod("card")}
                      className={`w-full p-6 rounded-lg border-2 transition text-left ${
                        paymentMethod === "card"
                          ? "border-primary bg-primary/10"
                          : "border-gray-200 hover:border-primary"
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${paymentMethod === "card" ? "bg-primary text-white" : "bg-gray-100"}`}>
                          <CreditCard size={24} />
                        </div>
                        <div>
                          <p className="font-bold">Card Payment</p>
                          <p className="text-sm text-muted-foreground">Visa, Mastercard, Verve</p>
                        </div>
                      </div>
                    </button>

                    {/* Bank Transfer */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod("bank")}
                      className={`w-full p-6 rounded-lg border-2 transition text-left ${
                        paymentMethod === "bank"
                          ? "border-primary bg-primary/10"
                          : "border-gray-200 hover:border-primary"
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${paymentMethod === "bank" ? "bg-primary text-white" : "bg-gray-100"}`}>
                          <Banknote size={24} />
                        </div>
                        <div>
                          <p className="font-bold">Bank Transfer</p>
                          <p className="text-sm text-muted-foreground">Direct bank transfer to our account</p>
                        </div>
                      </div>
                    </button>

                    {/* Card Details (if card selected) */}
                    {paymentMethod === "card" && (
                      <div className="space-y-4 bg-gray-50 p-6 rounded-lg">
                        <input
                          type="text"
                          name="cardName"
                          value={formData.cardName}
                          onChange={handleInputChange}
                          placeholder="Cardholder Name"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <input
                          type="text"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          placeholder="Card Number"
                          maxLength={16}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <input
                            type="text"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            placeholder="MM/YY"
                            required
                            className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                          <input
                            type="text"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            placeholder="CVV"
                            maxLength={3}
                            required
                            className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                        </div>
                      </div>
                    )}

                    {/* Bank Details (if bank selected) */}
                    {paymentMethod === "bank" && (
                      <div className="bg-gray-50 p-6 rounded-lg space-y-3">
                        <p className="font-semibold">Transfer Details (Coming Soon):</p>
                        <div className="space-y-2 text-sm">
                          <p><strong>Bank Name:</strong> [Bank Name]</p>
                          <p><strong>Account Name:</strong> 90SUPERSTORE</p>
                          <p><strong>Account Number:</strong> [Account Number]</p>
                          <p className="text-muted-foreground">Please include your order number as reference</p>
                        </div>
                      </div>
                    )}

                    {paymentMethod && (
                      <button
                        type="submit"
                        className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition"
                      >
                        Complete Order (₦{total.toLocaleString()})
                      </button>
                    )}
                  </form>
                )}
              </div>

              {/* Order Summary */}
              <div className="md:col-span-1">
                <div className="sticky top-20 bg-gray-50 p-6 rounded-lg">
                  <h3 className="font-bold mb-4">Order Summary</h3>

                  <div className="space-y-3 mb-6 pb-6 border-b">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Premium Wireless Earbuds x1</span>
                      <span>₦8,999</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Smart Watch Pro x2</span>
                      <span>₦31,998</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>₦40,997</span>
                    </div>
                    <div className="flex justify-between text-sm text-green-600">
                      <span className="text-muted-foreground">Shipping</span>
                      <span className="font-semibold">FREE</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax (7.5%)</span>
                      <span>₦3,075</span>
                    </div>
                  </div>

                  <div className="flex justify-between font-bold text-lg mt-6 pt-6 border-t">
                    <span>Total</span>
                    <span className="text-primary">₦{total.toLocaleString()}</span>
                  </div>

                  <div className="mt-6 space-y-2">
                    <p className="text-xs text-muted-foreground">✓ Secure checkout</p>
                    <p className="text-xs text-muted-foreground">✓ 7-day returns</p>
                    <p className="text-xs text-muted-foreground">✓ Money-back guarantee</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
