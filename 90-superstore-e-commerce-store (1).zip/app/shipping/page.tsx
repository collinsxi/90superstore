import Header from "@/components/header"
import Footer from "@/components/footer"
import { Truck, Clock, MapPin } from "lucide-react"

export default function ShippingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-3xl mx-auto space-y-12">
          <section>
            <h1 className="text-4xl font-bold mb-6">Shipping Information</h1>
            <p className="text-lg text-muted-foreground">
              At 90SUPERSTORE, we offer fast and reliable shipping to all parts of Nigeria.
            </p>
          </section>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="card-product p-6 text-center">
              <div className="inline-flex bg-blue-100 text-primary p-4 rounded-full mb-4">
                <Truck size={32} />
              </div>
              <h3 className="font-bold text-lg mb-2">Fast Delivery</h3>
              <p className="text-muted-foreground text-sm">Most orders delivered within 24-48 hours nationwide</p>
            </div>

            <div className="card-product p-6 text-center">
              <div className="inline-flex bg-blue-100 text-primary p-4 rounded-full mb-4">
                <MapPin size={32} />
              </div>
              <h3 className="font-bold text-lg mb-2">Nationwide Coverage</h3>
              <p className="text-muted-foreground text-sm">We ship to all states and territories across Nigeria</p>
            </div>

            <div className="card-product p-6 text-center">
              <div className="inline-flex bg-blue-100 text-primary p-4 rounded-full mb-4">
                <Clock size={32} />
              </div>
              <h3 className="font-bold text-lg mb-2">Real-Time Tracking</h3>
              <p className="text-muted-foreground text-sm">
                Track your order status in real-time from dispatch to delivery
              </p>
            </div>
          </div>

          <section>
            <h2 className="text-2xl font-bold mb-6">Shipping Rates & Times</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="p-4 text-left font-bold">Region</th>
                    <th className="p-4 text-left font-bold">Delivery Time</th>
                    <th className="p-4 text-left font-bold">Shipping Cost</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="p-4">Lagos & Environs</td>
                    <td className="p-4">24 hours</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">South-West States</td>
                    <td className="p-4">24-48 hours</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">South-South States</td>
                    <td className="p-4">24-48 hours</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">South-East States</td>
                    <td className="p-4">48 hours</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">North-Central States</td>
                    <td className="p-4">48-72 hours</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                  <tr>
                    <td className="p-4">North States</td>
                    <td className="p-4">3-5 business days</td>
                    <td className="p-4 text-green-600 font-bold">FREE</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6">Shipping FAQ</h2>
            <div className="space-y-6">
              <div>
                <h3 className="font-bold text-lg mb-2">When will my order arrive?</h3>
                <p className="text-muted-foreground">
                  Most orders are processed and dispatched within 24 hours. Delivery times vary based on your location,
                  typically 24-48 hours within major cities and up to 5 business days for remote areas.
                </p>
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">Is shipping free?</h3>
                <p className="text-muted-foreground">
                  Yes! We offer FREE nationwide shipping on all orders. No hidden charges or extra fees.
                </p>
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">How can I track my order?</h3>
                <p className="text-muted-foreground">
                  You can track your order using the order number provided in your confirmation email. Visit our Track
                  Order page to check real-time updates.
                </p>
              </div>
              <div>
                <h3 className="font-bold text-lg mb-2">What if my order is delayed?</h3>
                <p className="text-muted-foreground">
                  If your order is delayed beyond the estimated delivery time, please contact our support team
                  immediately via WhatsApp or email. We'll investigate and provide a solution.
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}
