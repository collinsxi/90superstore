import Header from "@/components/header"
import Footer from "@/components/footer"
import { Lock, Database, Users, Mail, Heart } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
          <p className="text-lg text-muted-foreground mb-8">
            We respect your privacy. Here's what we collect, how we use it, and how we protect it.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Heart className="text-primary" />
              The Bottom Line
            </h2>
            <div className="bg-green-50 border border-green-200 rounded-lg p-6">
              <p className="font-semibold mb-2">✓ We don't sell your data</p>
              <p className="font-semibold mb-2">✓ We don't share your info with third parties</p>
              <p className="font-semibold">✓ We only use your data to serve you better</p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Database className="text-primary" />
              What We Collect
            </h2>
            <p className="text-muted-foreground mb-4">When you use 90SUPERSTORE, we collect:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                📧 Your <strong>name, email, and phone number</strong> (for orders)
              </li>
              <li>
                📍 Your <strong>delivery address</strong> (to send products)
              </li>
              <li>
                💳 Your <strong>payment info</strong> (processed securely, we don't store it)
              </li>
              <li>
                🛒 Your <strong>browsing history</strong> (to recommend products you'll like)
              </li>
              <li>
                💬 Your <strong>chat messages</strong> (only when you contact us)
              </li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Mail className="text-primary" />
              How We Use Your Data
            </h2>
            <ul className="space-y-2 text-muted-foreground">
              <li>✓ Process your orders and send updates</li>
              <li>✓ Improve our products and service</li>
              <li>✓ Send promotions (only if you opt-in)</li>
              <li>✓ Protect against fraud and scams</li>
              <li>✓ Comply with Nigerian law</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Lock className="text-primary" />
              Data Security
            </h2>
            <p className="text-muted-foreground mb-4">Your security is our priority. Here's what we do:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                🔐 <strong>SSL Encryption:</strong> All data sent to us is encrypted
              </li>
              <li>
                🛡️ <strong>Secure Servers:</strong> Your data is stored on protected servers
              </li>
              <li>
                🚫 <strong>No Selling:</strong> We never sell your personal info
              </li>
              <li>
                📱 <strong>Limited Access:</strong> Only trusted staff see your data
              </li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Users className="text-primary" />
              Communication
            </h2>
            <p className="text-muted-foreground mb-4">We only reach out via:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>📧 Email (order updates, promotions if opted-in)</li>
              <li>📱 WhatsApp (order updates and customer support)</li>
              <li>💬 SMS (delivery tracking, if enabled)</li>
            </ul>
            <p className="text-muted-foreground mt-4">
              You can unsubscribe from marketing emails anytime. Just click the link at the bottom.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Your Rights</h2>
            <p className="text-muted-foreground mb-4">You have the right to:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>✓ Access all data we have about you</li>
              <li>✓ Update or correct your info anytime</li>
              <li>✓ Request data deletion (we'll remove it within 30 days)</li>
              <li>✓ Opt-out of marketing</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Cookies</h2>
            <p className="text-muted-foreground">
              We use cookies to remember you and improve your experience. You can disable them in your browser, but some
              features might not work as well.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Questions About Your Privacy?</h2>
            <div className="bg-primary text-white p-6 rounded-lg space-y-3">
              <p>We're transparent about how we use your data.</p>
              <p className="font-semibold">Contact us:</p>
              <a href="mailto:90Superstore@gmail.com" className="block underline hover:opacity-80">
                📧 90Superstore@gmail.com
              </a>
              <a href="https://wa.me/2348135642177" className="block underline hover:opacity-80">
                💬 WhatsApp: 08135642177
              </a>
            </div>
          </section>

          <p className="text-sm text-muted-foreground text-center mt-8">
            Last updated: November 2025 | We update this policy as our service evolves
          </p>
        </div>
      </main>
      <Footer />
    </div>
  )
}
