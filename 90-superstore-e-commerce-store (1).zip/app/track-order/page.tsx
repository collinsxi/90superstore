"use client"

import type React from "react"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Search, Package, Truck, CheckCircle, Clock } from "lucide-react"
import { useState } from "react"

export default function TrackOrderPage() {
  const [orderId, setOrderId] = useState("")
  const [tracked, setTracked] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setTracked(true)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Track Your Order</h1>
            <p className="text-muted-foreground text-lg">Enter your order number to track your shipment in real-time</p>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-12">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter Order Number (e.g., #90SS-ABC123XYZ)"
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                required
                className="flex-1 px-4 py-3 border border-border rounded-lg outline-none focus:border-primary"
              />
              <button type="submit" className="btn-primary inline-flex items-center gap-2">
                <Search size={20} />
                Track
              </button>
            </div>
          </form>

          {/* Sample Tracking Info */}
          {tracked && (
            <div className="card-product p-8 space-y-8">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Order Number</p>
                <h2 className="text-2xl font-bold">{orderId}</h2>
              </div>

              {/* Timeline */}
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="bg-green-500 text-white p-3 rounded-full mb-2">
                      <CheckCircle size={24} />
                    </div>
                    <div className="w-1 h-12 bg-green-500"></div>
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">Order Confirmed</h3>
                    <p className="text-sm text-muted-foreground">Nov 29, 2024 - 2:30 PM</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your order has been confirmed and is being prepared
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="bg-green-500 text-white p-3 rounded-full mb-2">
                      <Package size={24} />
                    </div>
                    <div className="w-1 h-12 bg-green-500"></div>
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">Shipped</h3>
                    <p className="text-sm text-muted-foreground">Nov 30, 2024 - 10:15 AM</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your package has been shipped and is on the way
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="bg-primary text-white p-3 rounded-full mb-2">
                      <Truck size={24} />
                    </div>
                    <div className="w-1 h-12 bg-gray-300"></div>
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">In Transit</h3>
                    <p className="text-sm text-muted-foreground">Dec 1, 2024 - Current</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your order is currently in transit to your location
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="bg-gray-300 text-gray-600 p-3 rounded-full mb-2">
                      <Clock size={24} />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">Delivered</h3>
                    <p className="text-sm text-muted-foreground">Expected: Dec 1, 2024</p>
                    <p className="text-sm text-muted-foreground mt-1">Your order will be delivered today</p>
                  </div>
                </div>
              </div>

              {/* Contact Support */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <p className="text-sm font-semibold text-primary mb-2">Need Help?</p>
                <p className="text-sm text-muted-foreground">
                  Contact our support team via WhatsApp or email: support@90superstore.com
                </p>
              </div>
            </div>
          )}

          {!tracked && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Enter your order number above to track your shipment</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
