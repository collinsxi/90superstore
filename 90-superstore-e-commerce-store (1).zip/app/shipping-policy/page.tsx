import Header from "@/components/header"
import Footer from "@/components/footer"
import { Truck, MapPin, Clock, Shield } from "lucide-react"

export default function ShippingPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="text-4xl font-bold mb-8">Shipping Policy</h1>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Truck className="text-primary" />
              Delivery Timeline
            </h2>
            <div className="bg-blue-50 border border-primary/20 rounded-lg p-6 space-y-3">
              <p className="font-semibold">🇳🇬 Nationwide Nigeria Delivery:</p>
              <p className="text-muted-foreground">
                • <strong>Standard:</strong> 1-3 business days within major cities (Lagos, Abuja, Kano)
              </p>
              <p className="text-muted-foreground">
                • <strong>Regional:</strong> 3-5 business days for other states
              </p>
              <p className="text-muted-foreground">
                • <strong>Remote:</strong> 5-7 business days for remote areas
              </p>
              <p className="mt-4 font-semibold">🌍 International Shipping:</p>
              <p className="text-muted-foreground">
                • <strong>Europe & USA:</strong> 7-15 business days
              </p>
              <p className="text-muted-foreground">
                • <strong>Africa (Regional):</strong> 5-10 business days
              </p>
              <p className="text-muted-foreground">
                • <strong>Dropshipping Products:</strong> 7-12 business days (sourced from China)
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <MapPin className="text-primary" />
              Shipping Coverage
            </h2>
            <p className="text-muted-foreground">
              We ship to all states within Nigeria and selected international destinations. Shipping is available to
              both residential and commercial addresses.
            </p>
            <ul className="space-y-2 text-muted-foreground">
              <li>✓ All Nigerian States</li>
              <li>✓ Major cities in West Africa</li>
              <li>✓ USA, Canada, and Europe</li>
              <li>✓ UK and Middle East</li>
              <li>✓ Australia and parts of Asia</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Clock className="text-primary" />
              Tracking & Updates
            </h2>
            <p className="text-muted-foreground">Every order comes with real-time tracking. You'll receive:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>📧 Order confirmation email</li>
              <li>📱 SMS updates with tracking link</li>
              <li>📍 Real-time delivery location updates</li>
              <li>✅ Delivery confirmation</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Shield className="text-primary" />
              Shipping Protection
            </h2>
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 space-y-3">
              <p>
                ✓ <strong>Free Replacement:</strong> Lost or damaged packages are replaced at no extra cost
              </p>
              <p>
                ✓ <strong>Insurance Included:</strong> All packages covered with shipping insurance
              </p>
              <p>
                ✓ <strong>Money-Back Guarantee:</strong> 100% refund if package never arrives
              </p>
              <p>
                ✓ <strong>No Hidden Fees:</strong> Transparent pricing with no surprise charges
              </p>
              <p>
                ✓ <strong>Quality Packaging:</strong> All items carefully packaged to prevent damage
              </p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Shipping Rates</h2>
            <div className="bg-gray-50 rounded-lg p-6">
              <p className="font-semibold mb-4">🚚 Standard Shipping (Nigeria):</p>
              <p className="text-muted-foreground mb-4">FREE for orders above ₦5,000</p>
              <p className="text-muted-foreground mb-6">
                ₦500 - ₦2,000 for orders below ₦5,000 (depending on location)
              </p>

              <p className="font-semibold mb-4">✈️ International Shipping:</p>
              <p className="text-muted-foreground">Calculated at checkout based on weight, destination, and carrier</p>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">FAQ</h2>
            <div className="space-y-4">
              <div>
                <p className="font-semibold mb-2">What if my package is delayed?</p>
                <p className="text-muted-foreground">
                  Contact us within 48 hours. We'll investigate and provide an update or compensation.
                </p>
              </div>
              <div>
                <p className="font-semibold mb-2">Can I change my delivery address?</p>
                <p className="text-muted-foreground">
                  Yes, within 1 hour of placing the order. Chat with us on WhatsApp: 08135642177
                </p>
              </div>
              <div>
                <p className="font-semibold mb-2">Do you offer express delivery?</p>
                <p className="text-muted-foreground">
                  Yes! Select "Express" at checkout for next-day delivery in major cities.
                </p>
              </div>
            </div>
          </section>

          <div className="bg-primary text-white p-8 rounded-lg text-center">
            <p className="text-lg font-semibold mb-2">Questions about shipping?</p>
            <p className="mb-4">Contact us on WhatsApp or email</p>
            <a href="https://wa.me/2348135642177" className="underline hover:opacity-80">
              Chat on WhatsApp
            </a>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
