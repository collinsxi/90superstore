"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import { Trash2, Plus, Minus, ArrowLeft } from "lucide-react"
import { useState } from "react"

interface CartItem {
  id: number
  name: string
  price: number
  originalPrice: number
  quantity: number
  image: string
}

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([
    {
      id: 1,
      name: "Premium Wireless Earbuds",
      price: 8999,
      originalPrice: 12999,
      quantity: 1,
      image: "/placeholder.svg?key=cart1",
    },
    {
      id: 2,
      name: "Smart Watch Pro",
      price: 15999,
      originalPrice: 19999,
      quantity: 2,
      image: "/placeholder.svg?key=cart2",
    },
  ])

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(id)
    } else {
      setItems(items.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
    }
  }

  const removeItem = (id: number) => {
    setItems(items.filter((item) => item.id !== id))
  }

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = subtotal > 0 ? 0 : 0 // Free shipping
  const tax = Math.round(subtotal * 0.075) // 7.5% tax
  const total = subtotal + shipping + tax

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        <Link href="/" className="inline-flex items-center gap-2 text-primary hover:underline mb-8">
          <ArrowLeft size={20} />
          Continue Shopping
        </Link>

        <h1 className="text-4xl font-bold mb-12">Shopping Cart</h1>

        {items.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-2xl font-bold mb-6">Your cart is empty</p>
            <Link href="/shop" className="btn-primary inline-block">
              Start Shopping
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              {items.map((item) => (
                <div key={item.id} className="card-product p-6 flex gap-6">
                  {/* Item Image */}
                  <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Item Details */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-foreground mb-2 line-clamp-2">{item.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      SKU: PROD-{item.id.toString().padStart(5, "0")}
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-primary">₦{item.price.toLocaleString()}</span>
                      <span className="text-sm line-through text-muted-foreground">
                        ₦{item.originalPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Quantity & Remove */}
                  <div className="flex flex-col items-end justify-between">
                    <button onClick={() => removeItem(item.id)} className="text-red-500 hover:text-red-700 transition">
                      <Trash2 size={20} />
                    </button>

                    <div className="flex items-center border border-border rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-gray-100"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="px-4 font-semibold">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-gray-100"
                      >
                        <Plus size={16} />
                      </button>
                    </div>

                    <p className="font-bold text-foreground">₦{(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="card-product p-6 h-fit sticky top-20">
              <h2 className="text-2xl font-bold mb-6">Order Summary</h2>

              <div className="space-y-4 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-semibold">₦{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-semibold text-green-600">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax (7.5%)</span>
                  <span className="font-semibold">₦{tax.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex justify-between mb-6">
                <span className="text-xl font-bold">Total</span>
                <span className="text-2xl font-bold text-primary">₦{total.toLocaleString()}</span>
              </div>

              <Link href="/checkout" className="btn-primary w-full block text-center mb-3">
                Proceed to Checkout
              </Link>

              <button className="w-full btn-secondary">Continue Shopping</button>

              {/* Trust Info */}
              <div className="mt-6 pt-6 border-t border-border space-y-3 text-sm text-muted-foreground">
                <p>✓ Secure SSL encryption</p>
                <p>✓ Money-back guarantee</p>
                <p>✓ 24/7 customer support</p>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
