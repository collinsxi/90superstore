"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import Link from "next/link"
import { Star, ShoppingCart, Flame } from "lucide-react"

const hotDeals = [
  {
    id: 1,
    name: "Premium Wireless Earbuds",
    price: "₦8,999",
    originalPrice: "₦12,999",
    discount: "25%",
    rating: 4.8,
    image: "/placeholder.svg?key=deal1",
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    price: "₦15,999",
    originalPrice: "₦19,999",
    discount: "20%",
    rating: 4.7,
    image: "/placeholder.svg?key=deal2",
  },
  {
    id: 3,
    name: "USB-C Fast Charger",
    price: "₦3,499",
    originalPrice: "₦4,999",
    discount: "30%",
    rating: 4.9,
    image: "/placeholder.svg?key=deal3",
  },
  {
    id: 4,
    name: "Phone Stand Mount",
    price: "₦1,999",
    originalPrice: "₦2,999",
    discount: "33%",
    rating: 4.6,
    image: "/placeholder.svg?key=deal4",
  },
  {
    id: 5,
    name: "Portable Power Bank",
    price: "₦9,999",
    originalPrice: "₦14,999",
    discount: "33%",
    rating: 4.7,
    image: "/placeholder.svg?key=deal5",
  },
  {
    id: 6,
    name: "Bluetooth Speaker",
    price: "₦7,999",
    originalPrice: "₦11,999",
    discount: "33%",
    rating: 4.8,
    image: "/placeholder.svg?key=deal6",
  },
]

export default function HotDealsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-12">
        <div className="flex items-center gap-3 mb-8">
          <Flame size={32} className="text-red-500" />
          <h1 className="text-4xl font-bold">Hot Deals</h1>
        </div>

        <p className="text-lg text-muted-foreground mb-12">
          Limited-time offers on premium products. Grab these deals before they're gone!
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {hotDeals.map((deal) => (
            <Link key={deal.id} href={`/product/${deal.id}`} className="card-product group overflow-hidden">
              <div className="relative overflow-hidden bg-gray-100 h-48">
                <img
                  src={deal.image || "/placeholder.svg"}
                  alt={deal.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                />
                <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  {deal.discount} OFF
                </div>
              </div>

              <div className="p-4 space-y-3">
                <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition">
                  {deal.name}
                </h3>

                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={14}
                      className={i < Math.floor(deal.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-primary">{deal.price}</span>
                  <span className="text-sm text-muted-foreground line-through">{deal.originalPrice}</span>
                </div>

                <button
                  onClick={(e) => {
                    e.preventDefault()
                  }}
                  className="w-full bg-red-500 text-white py-2 rounded-lg font-semibold hover:bg-red-600 transition flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={18} />
                  Grab Deal
                </button>
              </div>
            </Link>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}
