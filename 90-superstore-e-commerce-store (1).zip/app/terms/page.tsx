import Header from "@/components/header"
import Footer from "@/components/footer"
import { Shield, AlertCircle, Eye, Lock } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container-full py-16">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Last updated: November 2025 | Keep it real, keep it fair.
          </p>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Shield className="text-primary" />
              Agreement to Terms
            </h2>
            <p className="text-muted-foreground">
              By using 90SUPERSTORE, you agree to follow these terms. If you don't agree, don't use the store. It's that
              simple.
            </p>
            <div className="bg-blue-50 border border-primary/20 rounded-lg p-4 text-sm text-muted-foreground">
              We reserve the right to update these terms anytime. Major changes? We'll notify you.
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Eye className="text-primary" />
              Buyer Responsibilities
            </h2>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                ✓ Provide <strong>correct delivery address</strong> - we're not responsible for wrong addresses
              </li>
              <li>
                ✓ Use 90SUPERSTORE for <strong>personal use only</strong> - no bulk reselling
              </li>
              <li>
                ✓ <strong>Don't copy or claim our digital products as yours</strong> - they're for personal use
              </li>
              <li>✓ Keep your account info accurate</li>
              <li>✓ Follow all local laws when using our store</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Lock className="text-primary" />
              Payment & Security
            </h2>
            <p className="text-muted-foreground">
              All payments on 90SUPERSTORE are <strong>100% secure</strong>. We use industry-standard encryption to
              protect your data.
            </p>
            <ul className="space-y-2 text-muted-foreground">
              <li>✓ Your payment info is never shared with third parties</li>
              <li>✓ Transactions are encrypted end-to-end</li>
              <li>✓ We accept multiple payment methods for safety</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <AlertCircle className="text-primary" />
              Digital Products
            </h2>
            <p className="text-muted-foreground">
              Digital products (eBooks, templates, AI prompts, etc.) are{" "}
              <strong>delivered instantly after purchase</strong>.
            </p>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                ✗ <strong>No refunds on digital products</strong> once downloaded
              </li>
              <li>✗ You cannot resell or share digital content</li>
              <li>✓ You get lifetime access to your download links</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Pricing & Changes</h2>
            <p className="text-muted-foreground">90SUPERSTORE reserves the right to:</p>
            <ul className="space-y-2 text-muted-foreground">
              <li>• Update product prices without notice</li>
              <li>• Modify or discontinue products</li>
              <li>• Limit quantities per customer</li>
            </ul>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Disputes & Resolution</h2>
            <p className="text-muted-foreground">
              Got an issue? <strong>We'll try to resolve it within 24-48 hours.</strong> Contact us first via WhatsApp
              or email before any legal action.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Questions?</h2>
            <div className="bg-primary text-white p-6 rounded-lg">
              <p className="mb-4">We're here to help, not hide behind legal jargon.</p>
              <a href="https://wa.me/2348135642177" className="underline hover:opacity-80">
                Chat with us on WhatsApp
              </a>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}
