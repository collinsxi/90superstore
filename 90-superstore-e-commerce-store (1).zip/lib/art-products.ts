export interface ArtProduct {
  id: string
  title: string
  artist: string
  category: string
  basePrice: number
  rating: number
  reviews: number
  image: string
  images: string[]
  description: string
  details: string
  sizes: {
    name: string
    price: number
  }[]
  frames: {
    name: string
    price: number
  }[]
  inStock: boolean
}

export const artProducts: ArtProduct[] = [
  {
    id: "art-1",
    title: "Amazing Grace — Inspirational Wall Frame",
    artist: "Premium Collection",
    category: "Framed Art",
    basePrice: 8000,
    rating: 4.9,
    reviews: 48,
    image: "/gallery-abstract-art-1.jpg",
    images: ["/gallery-abstract-art-1.jpg", "/gallery-custom-frame.jpg"],
    description:
      "Transform your space with this powerful inspirational artwork designed to inspire hope, faith, and purpose. Printed in high quality with sharp detail and rich colors for a premium finish. Perfect for home, office, or spiritual spaces.",
    details:
      "This stunning piece combines elegant typography with inspiring imagery. Each print is produced on premium matte paper using high-definition printing technology to ensure vibrant colors and lasting quality. The artwork is perfect for creating a motivational atmosphere in any space.",
    sizes: [
      { name: "A4", price: 8000 },
      { name: "A3", price: 15000 },
      { name: "A2", price: 25000 },
    ],
    frames: [
      { name: "Print Only", price: 0 },
      { name: "Black Frame (+ ₦5,000)", price: 5000 },
      { name: "White Frame (+ ₦5,000)", price: 5000 },
    ],
    inStock: true,
  },
  {
    id: "art-2",
    title: "Abstract Serenity",
    artist: "Contemporary Collection",
    category: "Framed Art",
    basePrice: 45000,
    rating: 4.8,
    reviews: 32,
    image: "/gallery-abstract-art-1.jpg",
    images: ["/gallery-abstract-art-1.jpg"],
    description: "A mesmerizing blend of colors and forms that evokes calm and contemplation.",
    details: "Premium framed artwork with gallery-quality finish.",
    sizes: [
      { name: "A3", price: 45000 },
      { name: "A2", price: 65000 },
    ],
    frames: [
      { name: "Black Frame", price: 0 },
      { name: "White Frame", price: 0 },
      { name: "Natural Wood", price: 8000 },
    ],
    inStock: true,
  },
  {
    id: "art-3",
    title: "Urban Landscape",
    artist: "Modern Series",
    category: "Wall Posters",
    basePrice: 35000,
    rating: 4.6,
    reviews: 24,
    image: "/gallery-urban-landscape.jpg",
    images: ["/gallery-urban-landscape.jpg"],
    description: "Contemporary cityscape illustration with vibrant urban energy.",
    details: "Perfect for modern interiors and urban-themed spaces.",
    sizes: [
      { name: "A3", price: 35000 },
      { name: "A2", price: 50000 },
    ],
    frames: [
      { name: "Print Only", price: 0 },
      { name: "Black Frame", price: 5000 },
      { name: "White Frame", price: 5000 },
    ],
    inStock: true,
  },
]
